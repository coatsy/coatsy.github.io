using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using Microsoft.Win32;

namespace TFSVer
{
    class Program
    {


        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
            Console.WriteLine("TFSVer - Version Information for Team Foundation Server");
            Console.WriteLine();
            Console.WriteLine("Usage: TFSVer");
                return;

            }

            StringBuilder VersionInfo = new StringBuilder("Team Foundation Server Version Information\n==========================================\n");
                                                           
            // go and get the version info
            // based on Rob Caron's Blog Post http://blogs.msdn.com/robcaron/archive/2006/08/15/701843.aspx

            /*
             1. On the application-tier computer, check the file version of Microsoft.TeamFoundation.Server.dll. 
             
             You'll find this file here:

                %PROGRAMFILES%
                  \Microsoft Visual Studio 2005 Team Foundation Server
                    \Web Services
                      \Services
                        \Bin

                Here's the key to determine which release of Team Foundation Server you have:

                8.0.50727.43 = Beta 3 Refresh 
                8.0.50727.127 = Release Candidate 
                8.0.50727.147 = RTM (final shipping release of the product)
                Update: The version number for Visual Studio 2005 SP1 is 8.0.50727.762.
             */

            string DllVersion = "";
            string tfsVersion = "Unrecognised";
            bool RTMorLater = false;
            try 
	        {	
                FileVersionInfo TheFile = FileVersionInfo.GetVersionInfo(Environment.GetEnvironmentVariable("PROGRAMFILES") + "\\Microsoft Visual Studio 2005 Team Foundation Server\\Web Services\\Services\\Bin\\Microsoft.TeamFoundation.Server.dll");
                DllVersion = TheFile.FileVersion;
                switch (DllVersion)
	            {
                    case "8.0.50727.43":
                    {
                        tfsVersion = "Beta 3 Refresh";
                        break;
                    }

                    case "8.0.50727.127":
                    {
                        tfsVersion = "Release Candidate";
                        break;
                    }

                    case "8.0.50727.147":
                    {
                        tfsVersion = "RTM";
                        RTMorLater = true;
                        break;
                    }

                    case "8.0.50727.762":
                    {
                        tfsVersion = "SP1";
                        RTMorLater = true;
                        break;
                    }

                    default:
                    {
                        break;
                    }

	            }
                
                VersionInfo.AppendLine(string.Format("TFS Version: {0}", tfsVersion));

                // now go and find the Edition (If we're in RTM or later)
                if (RTMorLater)
                {
                    /*
                        If you have the RTM release, the next check is to see which edition of Team Foundation Server you have. To do this, open Registry Editor (regedt32.exe) and navigate down to this key:

                        HKEY_LOCAL_MACHINE
                          \SOFTWARE
                            \Microsoft
                              \VisualStudio
                                \8.0
                                  \TeamFoundation
                                    \Registration

                        In this key, you'll find a value named, Edition_CT, which is the clear text equivalent of the encrypted data in Edition. Here's the key to determine which edition you have:

                        "Full" = Team Foundation Server ("Standard Edition") 
                        "Trial" = Team Foundation Server 180-day Trial Edition 
                        "Workgroup" = Team Foundation Server Workgroup Edition 
                     */

                    string Edition = "unknown";
                    string rk = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\VisualStudio\\8.0\\TeamFoundation\\Registration").GetValue("Edition_CT").ToString();

                    switch (rk)
                    {
                        case "Full":
                            {
                                Edition = "Team Foundation Server (\"Standard Edition\")";
                                break;
                            }
                        case "Trial":
                            {
                                Edition = "Team Foundation Server 180-day Trial Edition";
                                break;
                            }
                        case "Workgroup":
                            {
                                Edition = "Team Foundation Server Workgroup Edition";
                                break;
                            }
                        default:
                            break;
                    }

                    VersionInfo.AppendLine(string.Format("Edition: {0}", Edition));

                }
   		
	        }
	        catch (FileNotFoundException fnfEx)
	        {
		        VersionInfo.AppendLine("TFS Not Installed on this machine");
	        }

            Console.WriteLine(VersionInfo.ToString());
            Console.WriteLine("Press any key to continue ...");
            Console.ReadKey();

        }

     }
}
