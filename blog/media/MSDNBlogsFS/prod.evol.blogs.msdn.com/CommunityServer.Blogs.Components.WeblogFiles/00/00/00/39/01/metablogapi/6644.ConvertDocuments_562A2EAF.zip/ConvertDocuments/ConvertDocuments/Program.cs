﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SharePoint;
using Microsoft.Office.Word.Server.Conversions;

namespace ConvertDocuments
{
  class Program
  {

    // If you manually installed Word Automation Services, then replace the name
    // in the following line with the name that you assigned to the service when
    // you installed it.
    static string cWordServicesName = "Word Automation Services";
    static string siteUrl = "http://localhost";

    static void Main(string[] args)
    {
      SingleConv();
      BulkConv();
    }

    private static void SingleConv()
    {
      using (SPSite spSite = new SPSite(siteUrl))
      {
        ConversionJob job = new ConversionJob(cWordServicesName);
        job.UserToken = spSite.UserToken;
        job.Settings.UpdateFields = true;
        job.Settings.OutputFormat = SaveFormat.PDF;
        job.AddFile(siteUrl + "/Created%20Docs/MyVeryVeryCoolDoc.docx",
            siteUrl + "/Converted%20Docs/MyVeryVeryCoolDoc.pdf");
        job.Start();
        Console.WriteLine("Job ID: {0} started", job.JobId);
        Console.WriteLine("Press the any key ...");
        Console.ReadKey();
        Console.WriteLine("=======================================");
      }
    }

    private static void BulkConv()
    {
      using (SPSite spSite = new SPSite(siteUrl))
      {
        Console.WriteLine("Starting conversion job");
        ConversionJob job = new ConversionJob(cWordServicesName);
        job.UserToken = spSite.UserToken;
        job.Settings.UpdateFields = true;
        job.Settings.OutputFormat = SaveFormat.PDF;
        job.Settings.OutputSaveBehavior = SaveBehavior.AlwaysOverwrite;
        SPList listToConvert = spSite.RootWeb.Lists["Created Docs"];
        SPList listToPopulate = spSite.RootWeb.Lists["Converted Docs"];
        job.AddLibrary(listToConvert, listToPopulate);
        job.Start();
        Console.WriteLine("Bulk conversion job {0} started", job.JobId);
        ConversionJobStatus status = new ConversionJobStatus(cWordServicesName,
            job.JobId, null);
        Console.WriteLine("Number of documents in conversion job: {0}", status.Count);
        while (true)
        {
          System.Threading.Thread.Sleep(5000);

          status.Refresh();
          if (status.Count == status.Succeeded + status.Failed)
          {
            Console.WriteLine("{2} Completed, Successful: {0}, Failed: {1}",
                status.Succeeded, status.Failed, DateTime.Now);
            break;
          }
          Console.WriteLine("{2} In progress, Successful: {0}, Failed: {1}",
              status.Succeeded, status.Failed, DateTime.Now);
        }

        Console.ReadKey();
      }
    }
  }
}
