﻿namespace OpenXMLDocumentGeneration
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateOneDocumentLocallyButton = new System.Windows.Forms.Button();
            this.CreateManyDocumentsLocallyButton = new System.Windows.Forms.Button();
            this.CreateManyDocumentsOnSharePointButton = new System.Windows.Forms.Button();
            this.CreateOneDocumentOnSharePointButton = new System.Windows.Forms.Button();
            this.NumberOfDocumentsToCreate = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.NumberOfDocumentsToCreate)).BeginInit();
            this.SuspendLayout();
            // 
            // CreateOneDocumentLocallyButton
            // 
            this.CreateOneDocumentLocallyButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CreateOneDocumentLocallyButton.Location = new System.Drawing.Point(13, 13);
            this.CreateOneDocumentLocallyButton.Name = "CreateOneDocumentLocallyButton";
            this.CreateOneDocumentLocallyButton.Size = new System.Drawing.Size(398, 35);
            this.CreateOneDocumentLocallyButton.TabIndex = 0;
            this.CreateOneDocumentLocallyButton.Text = "Create One Document Locally";
            this.CreateOneDocumentLocallyButton.UseVisualStyleBackColor = true;
            this.CreateOneDocumentLocallyButton.Click += new System.EventHandler(this.CreateOneDocumentLocallyButton_Click);
            // 
            // CreateManyDocumentsLocallyButton
            // 
            this.CreateManyDocumentsLocallyButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CreateManyDocumentsLocallyButton.Location = new System.Drawing.Point(13, 54);
            this.CreateManyDocumentsLocallyButton.Name = "CreateManyDocumentsLocallyButton";
            this.CreateManyDocumentsLocallyButton.Size = new System.Drawing.Size(398, 35);
            this.CreateManyDocumentsLocallyButton.TabIndex = 1;
            this.CreateManyDocumentsLocallyButton.Text = "Create Many Documents Locally";
            this.CreateManyDocumentsLocallyButton.UseVisualStyleBackColor = true;
            this.CreateManyDocumentsLocallyButton.Click += new System.EventHandler(this.CreateManyDocumentsLocallyButton_Click);
            // 
            // CreateManyDocumentsOnSharePointButton
            // 
            this.CreateManyDocumentsOnSharePointButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CreateManyDocumentsOnSharePointButton.Location = new System.Drawing.Point(13, 136);
            this.CreateManyDocumentsOnSharePointButton.Name = "CreateManyDocumentsOnSharePointButton";
            this.CreateManyDocumentsOnSharePointButton.Size = new System.Drawing.Size(398, 35);
            this.CreateManyDocumentsOnSharePointButton.TabIndex = 3;
            this.CreateManyDocumentsOnSharePointButton.Text = "Create Many Documents on SharePoint";
            this.CreateManyDocumentsOnSharePointButton.UseVisualStyleBackColor = true;
            this.CreateManyDocumentsOnSharePointButton.Click += new System.EventHandler(this.CreateManyDocumentsOnSharePointButton_Click);
            // 
            // CreateOneDocumentOnSharePointButton
            // 
            this.CreateOneDocumentOnSharePointButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CreateOneDocumentOnSharePointButton.Location = new System.Drawing.Point(13, 95);
            this.CreateOneDocumentOnSharePointButton.Name = "CreateOneDocumentOnSharePointButton";
            this.CreateOneDocumentOnSharePointButton.Size = new System.Drawing.Size(398, 35);
            this.CreateOneDocumentOnSharePointButton.TabIndex = 2;
            this.CreateOneDocumentOnSharePointButton.Text = "Create One Document on SharePoint";
            this.CreateOneDocumentOnSharePointButton.UseVisualStyleBackColor = true;
            this.CreateOneDocumentOnSharePointButton.Click += new System.EventHandler(this.CreateOneDocumentOnSharePointButton_Click);
            // 
            // NumberOfDocumentsToCreate
            // 
            this.NumberOfDocumentsToCreate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.NumberOfDocumentsToCreate.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NumberOfDocumentsToCreate.Location = new System.Drawing.Point(418, 58);
            this.NumberOfDocumentsToCreate.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumberOfDocumentsToCreate.Name = "NumberOfDocumentsToCreate";
            this.NumberOfDocumentsToCreate.Size = new System.Drawing.Size(84, 31);
            this.NumberOfDocumentsToCreate.TabIndex = 4;
            this.NumberOfDocumentsToCreate.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 182);
            this.Controls.Add(this.NumberOfDocumentsToCreate);
            this.Controls.Add(this.CreateManyDocumentsOnSharePointButton);
            this.Controls.Add(this.CreateOneDocumentOnSharePointButton);
            this.Controls.Add(this.CreateManyDocumentsLocallyButton);
            this.Controls.Add(this.CreateOneDocumentLocallyButton);
            this.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.NumberOfDocumentsToCreate)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CreateOneDocumentLocallyButton;
        private System.Windows.Forms.Button CreateManyDocumentsLocallyButton;
        private System.Windows.Forms.Button CreateManyDocumentsOnSharePointButton;
        private System.Windows.Forms.Button CreateOneDocumentOnSharePointButton;
        private System.Windows.Forms.NumericUpDown NumberOfDocumentsToCreate;
    }
}

