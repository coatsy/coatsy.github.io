﻿using DocumentFormat.OpenXml.Packaging;
using Ap = DocumentFormat.OpenXml.ExtendedProperties;
using Vt = DocumentFormat.OpenXml.VariantTypes;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Wordprocessing;
using A = DocumentFormat.OpenXml.Drawing;
using M = DocumentFormat.OpenXml.Math;
using Ovml = DocumentFormat.OpenXml.Vml.Office;
using V = DocumentFormat.OpenXml.Vml;
using W14 = DocumentFormat.OpenXml.Office2010.Word;
using System.IO;

namespace OpenXMLDocumentGeneration
{
  public class DocumentCreator
  {

    internal MemoryStream CreatePackage()
    {

      MemoryStream ms = new MemoryStream();
      using (WordprocessingDocument package = 
        WordprocessingDocument.Create
        (ms, WordprocessingDocumentType.Document))
      {
        CreateParts(package);
      }

      return ms;

    }

    // Creates a WordprocessingDocument.
    public void CreatePackage(string filePath)
    {
      using (WordprocessingDocument package = 
        WordprocessingDocument.Create
        (filePath, WordprocessingDocumentType.Document))
      {
        CreateParts(package);

      }
    }

    // Adds child parts and generates content of the specified part.
    private void CreateParts(WordprocessingDocument document)
    {
      ExtendedFilePropertiesPart extendedFilePropertiesPart1 = document.AddNewPart<ExtendedFilePropertiesPart>("rId3");
      GenerateExtendedFilePropertiesPart1Content(extendedFilePropertiesPart1);

      MainDocumentPart mainDocumentPart1 = document.AddMainDocumentPart();
      GenerateMainDocumentPart1Content(mainDocumentPart1);

      StylesWithEffectsPart stylesWithEffectsPart1 = mainDocumentPart1.AddNewPart<StylesWithEffectsPart>("rId3");
      GenerateStylesWithEffectsPart1Content(stylesWithEffectsPart1);

      ThemePart themePart1 = mainDocumentPart1.AddNewPart<ThemePart>("rId7");
      GenerateThemePart1Content(themePart1);

      StyleDefinitionsPart styleDefinitionsPart1 = mainDocumentPart1.AddNewPart<StyleDefinitionsPart>("rId2");
      GenerateStyleDefinitionsPart1Content(styleDefinitionsPart1);

      NumberingDefinitionsPart numberingDefinitionsPart1 = mainDocumentPart1.AddNewPart<NumberingDefinitionsPart>("rId1");
      GenerateNumberingDefinitionsPart1Content(numberingDefinitionsPart1);

      FontTablePart fontTablePart1 = mainDocumentPart1.AddNewPart<FontTablePart>("rId6");
      GenerateFontTablePart1Content(fontTablePart1);

      WebSettingsPart webSettingsPart1 = mainDocumentPart1.AddNewPart<WebSettingsPart>("rId5");
      GenerateWebSettingsPart1Content(webSettingsPart1);

      DocumentSettingsPart documentSettingsPart1 = mainDocumentPart1.AddNewPart<DocumentSettingsPart>("rId4");
      GenerateDocumentSettingsPart1Content(documentSettingsPart1);

      SetPackageProperties(document);
    }

    // Generates content of extendedFilePropertiesPart1.
    private void GenerateExtendedFilePropertiesPart1Content(ExtendedFilePropertiesPart extendedFilePropertiesPart1)
    {
      Ap.Properties properties1 = new Ap.Properties();
      properties1.AddNamespaceDeclaration("vt", "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes");
      Ap.Template template1 = new Ap.Template();
      template1.Text = "Normal.dotm";
      Ap.TotalTime totalTime1 = new Ap.TotalTime();
      totalTime1.Text = "0";
      Ap.Pages pages1 = new Ap.Pages();
      pages1.Text = "1";
      Ap.Words words1 = new Ap.Words();
      words1.Text = "27";
      Ap.Characters characters1 = new Ap.Characters();
      characters1.Text = "160";
      Ap.Application application1 = new Ap.Application();
      application1.Text = "Microsoft Office Word";
      Ap.DocumentSecurity documentSecurity1 = new Ap.DocumentSecurity();
      documentSecurity1.Text = "0";
      Ap.Lines lines1 = new Ap.Lines();
      lines1.Text = "1";
      Ap.Paragraphs paragraphs1 = new Ap.Paragraphs();
      paragraphs1.Text = "1";
      Ap.ScaleCrop scaleCrop1 = new Ap.ScaleCrop();
      scaleCrop1.Text = "false";

      Ap.HeadingPairs headingPairs1 = new Ap.HeadingPairs();

      Vt.VTVector vTVector1 = new Vt.VTVector() { BaseType = Vt.VectorBaseValues.Variant, Size = (UInt32Value)2U };

      Vt.Variant variant1 = new Vt.Variant();
      Vt.VTLPSTR vTLPSTR1 = new Vt.VTLPSTR();
      vTLPSTR1.Text = "Title";

      variant1.Append(vTLPSTR1);

      Vt.Variant variant2 = new Vt.Variant();
      Vt.VTInt32 vTInt321 = new Vt.VTInt32();
      vTInt321.Text = "1";

      variant2.Append(vTInt321);

      vTVector1.Append(variant1);
      vTVector1.Append(variant2);

      headingPairs1.Append(vTVector1);

      Ap.TitlesOfParts titlesOfParts1 = new Ap.TitlesOfParts();

      Vt.VTVector vTVector2 = new Vt.VTVector() { BaseType = Vt.VectorBaseValues.Lpstr, Size = (UInt32Value)1U };
      Vt.VTLPSTR vTLPSTR2 = new Vt.VTLPSTR();
      vTLPSTR2.Text = "";

      vTVector2.Append(vTLPSTR2);

      titlesOfParts1.Append(vTVector2);
      Ap.Company company1 = new Ap.Company();
      company1.Text = "Microsoft";
      Ap.LinksUpToDate linksUpToDate1 = new Ap.LinksUpToDate();
      linksUpToDate1.Text = "false";
      Ap.CharactersWithSpaces charactersWithSpaces1 = new Ap.CharactersWithSpaces();
      charactersWithSpaces1.Text = "186";
      Ap.SharedDocument sharedDocument1 = new Ap.SharedDocument();
      sharedDocument1.Text = "false";
      Ap.HyperlinksChanged hyperlinksChanged1 = new Ap.HyperlinksChanged();
      hyperlinksChanged1.Text = "false";
      Ap.ApplicationVersion applicationVersion1 = new Ap.ApplicationVersion();
      applicationVersion1.Text = "14.0000";

      properties1.Append(template1);
      properties1.Append(totalTime1);
      properties1.Append(pages1);
      properties1.Append(words1);
      properties1.Append(characters1);
      properties1.Append(application1);
      properties1.Append(documentSecurity1);
      properties1.Append(lines1);
      properties1.Append(paragraphs1);
      properties1.Append(scaleCrop1);
      properties1.Append(headingPairs1);
      properties1.Append(titlesOfParts1);
      properties1.Append(company1);
      properties1.Append(linksUpToDate1);
      properties1.Append(charactersWithSpaces1);
      properties1.Append(sharedDocument1);
      properties1.Append(hyperlinksChanged1);
      properties1.Append(applicationVersion1);

      extendedFilePropertiesPart1.Properties = properties1;
    }

    // Generates content of mainDocumentPart1.
    private void GenerateMainDocumentPart1Content(MainDocumentPart mainDocumentPart1)
    {
      Document document1 = new Document() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14 wp14" } };
      document1.AddNamespaceDeclaration("wpc", "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas");
      document1.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
      document1.AddNamespaceDeclaration("o", "urn:schemas-microsoft-com:office:office");
      document1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
      document1.AddNamespaceDeclaration("m", "http://schemas.openxmlformats.org/officeDocument/2006/math");
      document1.AddNamespaceDeclaration("v", "urn:schemas-microsoft-com:vml");
      document1.AddNamespaceDeclaration("wp14", "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing");
      document1.AddNamespaceDeclaration("wp", "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing");
      document1.AddNamespaceDeclaration("w10", "urn:schemas-microsoft-com:office:word");
      document1.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
      document1.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");
      document1.AddNamespaceDeclaration("wpg", "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup");
      document1.AddNamespaceDeclaration("wpi", "http://schemas.microsoft.com/office/word/2010/wordprocessingInk");
      document1.AddNamespaceDeclaration("wne", "http://schemas.microsoft.com/office/word/2006/wordml");
      document1.AddNamespaceDeclaration("wps", "http://schemas.microsoft.com/office/word/2010/wordprocessingShape");

      Body body1 = new Body();

      Paragraph paragraph1 = new Paragraph() { RsidParagraphAddition = "00C5783A", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "1428CC89", TextId = "77777777" };

      ParagraphProperties paragraphProperties1 = new ParagraphProperties();
      ParagraphStyleId paragraphStyleId1 = new ParagraphStyleId() { Val = "Title" };

      paragraphProperties1.Append(paragraphStyleId1);
      BookmarkStart bookmarkStart1 = new BookmarkStart() { Name = "_GoBack", Id = "0" };
      BookmarkEnd bookmarkEnd1 = new BookmarkEnd() { Id = "0" };

      Run run1 = new Run();
      Text text1 = new Text();
      text1.Text = "The OpenXML SDK Rocks";

      run1.Append(text1);

      paragraph1.Append(paragraphProperties1);
      paragraph1.Append(bookmarkStart1);
      paragraph1.Append(bookmarkEnd1);
      paragraph1.Append(run1);

      Paragraph paragraph2 = new Paragraph() { RsidParagraphAddition = "00146275", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "7C3B5A17", TextId = "77777777" };

      ParagraphProperties paragraphProperties2 = new ParagraphProperties();
      ParagraphStyleId paragraphStyleId2 = new ParagraphStyleId() { Val = "Heading1" };

      paragraphProperties2.Append(paragraphStyleId2);

      Run run2 = new Run();
      Text text2 = new Text();
      text2.Text = "There are lots of reasons";

      run2.Append(text2);

      paragraph2.Append(paragraphProperties2);
      paragraph2.Append(run2);

      Paragraph paragraph3 = new Paragraph() { RsidParagraphMarkRevision = "00146275", RsidParagraphAddition = "00EB3E0F", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "0BFC18A6", TextId = "77777777" };

      ParagraphProperties paragraphProperties3 = new ParagraphProperties();
      ParagraphStyleId paragraphStyleId3 = new ParagraphStyleId() { Val = "ListParagraph" };

      paragraphProperties3.Append(paragraphStyleId3);

      Run run3 = new Run() { RsidRunProperties = "00146275" };
      Text text3 = new Text();
      text3.Text = "Takes the heavy lifting out of the job";

      run3.Append(text3);

      paragraph3.Append(paragraphProperties3);
      paragraph3.Append(run3);

      Paragraph paragraph4 = new Paragraph() { RsidParagraphMarkRevision = "00146275", RsidParagraphAddition = "00EB3E0F", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "614A482F", TextId = "77777777" };

      ParagraphProperties paragraphProperties4 = new ParagraphProperties();
      ParagraphStyleId paragraphStyleId4 = new ParagraphStyleId() { Val = "ListParagraph" };

      paragraphProperties4.Append(paragraphStyleId4);

      Run run4 = new Run() { RsidRunProperties = "00146275" };
      Text text4 = new Text();
      text4.Text = "Wrappers for";

      run4.Append(text4);

      Run run5 = new Run() { RsidRunProperties = "00146275" };
      Break break1 = new Break();

      run5.Append(break1);
      ProofError proofError1 = new ProofError() { Type = ProofingErrorValues.SpellStart };

      Run run6 = new Run() { RsidRunProperties = "00146275" };

      RunProperties runProperties1 = new RunProperties();
      RunFonts runFonts1 = new RunFonts() { Ascii = "Consolas", HighAnsi = "Consolas", ComplexScript = "Consolas" };

      runProperties1.Append(runFonts1);
      Text text5 = new Text();
      text5.Text = "System.IO.Packaging";

      run6.Append(runProperties1);
      run6.Append(text5);
      ProofError proofError2 = new ProofError() { Type = ProofingErrorValues.SpellEnd };

      paragraph4.Append(paragraphProperties4);
      paragraph4.Append(run4);
      paragraph4.Append(run5);
      paragraph4.Append(proofError1);
      paragraph4.Append(run6);
      paragraph4.Append(proofError2);

      Paragraph paragraph5 = new Paragraph() { RsidParagraphMarkRevision = "00146275", RsidParagraphAddition = "00EB3E0F", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "79C00F88", TextId = "77777777" };

      ParagraphProperties paragraphProperties5 = new ParagraphProperties();
      ParagraphStyleId paragraphStyleId5 = new ParagraphStyleId() { Val = "ListParagraph" };

      paragraphProperties5.Append(paragraphStyleId5);

      Run run7 = new Run() { RsidRunProperties = "00146275" };
      Text text6 = new Text();
      text6.Text = "Document Reflector";

      run7.Append(text6);

      paragraph5.Append(paragraphProperties5);
      paragraph5.Append(run7);

      Paragraph paragraph6 = new Paragraph() { RsidParagraphMarkRevision = "00146275", RsidParagraphAddition = "00EB3E0F", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "5820DA27", TextId = "77777777" };

      ParagraphProperties paragraphProperties6 = new ParagraphProperties();
      ParagraphStyleId paragraphStyleId6 = new ParagraphStyleId() { Val = "ListParagraph" };

      paragraphProperties6.Append(paragraphStyleId6);

      Run run8 = new Run() { RsidRunProperties = "00146275" };
      Text text7 = new Text();
      text7.Text = "Document Validator";

      run8.Append(text7);

      paragraph6.Append(paragraphProperties6);
      paragraph6.Append(run8);

      Paragraph paragraph7 = new Paragraph() { RsidParagraphMarkRevision = "00146275", RsidParagraphAddition = "00EB3E0F", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "7F5DECD8", TextId = "77777777" };

      ParagraphProperties paragraphProperties7 = new ParagraphProperties();
      ParagraphStyleId paragraphStyleId7 = new ParagraphStyleId() { Val = "ListParagraph" };

      paragraphProperties7.Append(paragraphStyleId7);

      Run run9 = new Run() { RsidRunProperties = "00146275" };
      Text text8 = new Text();
      text8.Text = "Open XML Diff";

      run9.Append(text8);

      paragraph7.Append(paragraphProperties7);
      paragraph7.Append(run9);

      Paragraph paragraph8 = new Paragraph() { RsidParagraphMarkRevision = "00146275", RsidParagraphAddition = "00EB3E0F", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "51542323", TextId = "77777777" };

      ParagraphProperties paragraphProperties8 = new ParagraphProperties();
      ParagraphStyleId paragraphStyleId8 = new ParagraphStyleId() { Val = "ListParagraph" };

      paragraphProperties8.Append(paragraphStyleId8);

      Run run10 = new Run() { RsidRunProperties = "00146275" };
      Text text9 = new Text();
      text9.Text = "Documentation";

      run10.Append(text9);

      paragraph8.Append(paragraphProperties8);
      paragraph8.Append(run10);
      Paragraph paragraph9 = new Paragraph() { RsidParagraphMarkRevision = "00146275", RsidParagraphAddition = "00146275", RsidParagraphProperties = "00146275", RsidRunAdditionDefault = "00146275", ParagraphId = "23D4DB8B", TextId = "77777777" };

      SectionProperties sectionProperties1 = new SectionProperties() { RsidRPr = "00146275", RsidR = "00146275" };
      PageSize pageSize1 = new PageSize() { Width = (UInt32Value)11906U, Height = (UInt32Value)16838U };
      PageMargin pageMargin1 = new PageMargin() { Top = 1440, Right = (UInt32Value)1440U, Bottom = 1440, Left = (UInt32Value)1440U, Header = (UInt32Value)708U, Footer = (UInt32Value)708U, Gutter = (UInt32Value)0U };
      Columns columns1 = new Columns() { Space = "708" };
      DocGrid docGrid1 = new DocGrid() { LinePitch = 360 };

      sectionProperties1.Append(pageSize1);
      sectionProperties1.Append(pageMargin1);
      sectionProperties1.Append(columns1);
      sectionProperties1.Append(docGrid1);

      body1.Append(paragraph1);
      body1.Append(paragraph2);
      body1.Append(paragraph3);
      body1.Append(paragraph4);
      body1.Append(paragraph5);
      body1.Append(paragraph6);
      body1.Append(paragraph7);
      body1.Append(paragraph8);
      body1.Append(paragraph9);
      body1.Append(sectionProperties1);

      document1.Append(body1);

      mainDocumentPart1.Document = document1;
    }

    // Generates content of stylesWithEffectsPart1.
    private void GenerateStylesWithEffectsPart1Content(StylesWithEffectsPart stylesWithEffectsPart1)
    {
      Styles styles1 = new Styles() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14 wp14" } };
      styles1.AddNamespaceDeclaration("wpc", "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas");
      styles1.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
      styles1.AddNamespaceDeclaration("o", "urn:schemas-microsoft-com:office:office");
      styles1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
      styles1.AddNamespaceDeclaration("m", "http://schemas.openxmlformats.org/officeDocument/2006/math");
      styles1.AddNamespaceDeclaration("v", "urn:schemas-microsoft-com:vml");
      styles1.AddNamespaceDeclaration("wp14", "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing");
      styles1.AddNamespaceDeclaration("wp", "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing");
      styles1.AddNamespaceDeclaration("w10", "urn:schemas-microsoft-com:office:word");
      styles1.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
      styles1.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");
      styles1.AddNamespaceDeclaration("wpg", "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup");
      styles1.AddNamespaceDeclaration("wpi", "http://schemas.microsoft.com/office/word/2010/wordprocessingInk");
      styles1.AddNamespaceDeclaration("wne", "http://schemas.microsoft.com/office/word/2006/wordml");
      styles1.AddNamespaceDeclaration("wps", "http://schemas.microsoft.com/office/word/2010/wordprocessingShape");

      DocDefaults docDefaults1 = new DocDefaults();

      RunPropertiesDefault runPropertiesDefault1 = new RunPropertiesDefault();

      RunPropertiesBaseStyle runPropertiesBaseStyle1 = new RunPropertiesBaseStyle();
      RunFonts runFonts2 = new RunFonts() { AsciiTheme = ThemeFontValues.MinorHighAnsi, HighAnsiTheme = ThemeFontValues.MinorHighAnsi, EastAsiaTheme = ThemeFontValues.MinorHighAnsi, ComplexScriptTheme = ThemeFontValues.MinorBidi };
      FontSize fontSize1 = new FontSize() { Val = "22" };
      FontSizeComplexScript fontSizeComplexScript1 = new FontSizeComplexScript() { Val = "22" };
      Languages languages1 = new Languages() { Val = "en-AU", EastAsia = "en-AU", Bidi = "ar-SA" };

      runPropertiesBaseStyle1.Append(runFonts2);
      runPropertiesBaseStyle1.Append(fontSize1);
      runPropertiesBaseStyle1.Append(fontSizeComplexScript1);
      runPropertiesBaseStyle1.Append(languages1);

      runPropertiesDefault1.Append(runPropertiesBaseStyle1);

      ParagraphPropertiesDefault paragraphPropertiesDefault1 = new ParagraphPropertiesDefault();

      ParagraphPropertiesBaseStyle paragraphPropertiesBaseStyle1 = new ParagraphPropertiesBaseStyle();
      SpacingBetweenLines spacingBetweenLines1 = new SpacingBetweenLines() { After = "200", Line = "276", LineRule = LineSpacingRuleValues.Auto };

      paragraphPropertiesBaseStyle1.Append(spacingBetweenLines1);

      paragraphPropertiesDefault1.Append(paragraphPropertiesBaseStyle1);

      docDefaults1.Append(runPropertiesDefault1);
      docDefaults1.Append(paragraphPropertiesDefault1);

      LatentStyles latentStyles1 = new LatentStyles() { DefaultLockedState = false, DefaultUiPriority = 99, DefaultSemiHidden = true, DefaultUnhideWhenUsed = true, DefaultPrimaryStyle = false, Count = 267 };
      LatentStyleExceptionInfo latentStyleExceptionInfo1 = new LatentStyleExceptionInfo() { Name = "Normal", UiPriority = 0, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo2 = new LatentStyleExceptionInfo() { Name = "heading 1", UiPriority = 9, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo3 = new LatentStyleExceptionInfo() { Name = "heading 2", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo4 = new LatentStyleExceptionInfo() { Name = "heading 3", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo5 = new LatentStyleExceptionInfo() { Name = "heading 4", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo6 = new LatentStyleExceptionInfo() { Name = "heading 5", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo7 = new LatentStyleExceptionInfo() { Name = "heading 6", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo8 = new LatentStyleExceptionInfo() { Name = "heading 7", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo9 = new LatentStyleExceptionInfo() { Name = "heading 8", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo10 = new LatentStyleExceptionInfo() { Name = "heading 9", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo11 = new LatentStyleExceptionInfo() { Name = "toc 1", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo12 = new LatentStyleExceptionInfo() { Name = "toc 2", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo13 = new LatentStyleExceptionInfo() { Name = "toc 3", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo14 = new LatentStyleExceptionInfo() { Name = "toc 4", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo15 = new LatentStyleExceptionInfo() { Name = "toc 5", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo16 = new LatentStyleExceptionInfo() { Name = "toc 6", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo17 = new LatentStyleExceptionInfo() { Name = "toc 7", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo18 = new LatentStyleExceptionInfo() { Name = "toc 8", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo19 = new LatentStyleExceptionInfo() { Name = "toc 9", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo20 = new LatentStyleExceptionInfo() { Name = "caption", UiPriority = 35, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo21 = new LatentStyleExceptionInfo() { Name = "Title", UiPriority = 10, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo22 = new LatentStyleExceptionInfo() { Name = "Default Paragraph Font", UiPriority = 1 };
      LatentStyleExceptionInfo latentStyleExceptionInfo23 = new LatentStyleExceptionInfo() { Name = "Subtitle", UiPriority = 11, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo24 = new LatentStyleExceptionInfo() { Name = "Strong", UiPriority = 22, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo25 = new LatentStyleExceptionInfo() { Name = "Emphasis", UiPriority = 20, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo26 = new LatentStyleExceptionInfo() { Name = "Table Grid", UiPriority = 59, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo27 = new LatentStyleExceptionInfo() { Name = "Placeholder Text", UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo28 = new LatentStyleExceptionInfo() { Name = "No Spacing", UiPriority = 1, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo29 = new LatentStyleExceptionInfo() { Name = "Light Shading", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo30 = new LatentStyleExceptionInfo() { Name = "Light List", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo31 = new LatentStyleExceptionInfo() { Name = "Light Grid", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo32 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo33 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo34 = new LatentStyleExceptionInfo() { Name = "Medium List 1", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo35 = new LatentStyleExceptionInfo() { Name = "Medium List 2", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo36 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo37 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo38 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo39 = new LatentStyleExceptionInfo() { Name = "Dark List", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo40 = new LatentStyleExceptionInfo() { Name = "Colorful Shading", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo41 = new LatentStyleExceptionInfo() { Name = "Colorful List", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo42 = new LatentStyleExceptionInfo() { Name = "Colorful Grid", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo43 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 1", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo44 = new LatentStyleExceptionInfo() { Name = "Light List Accent 1", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo45 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 1", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo46 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 1", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo47 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 1", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo48 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 1", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo49 = new LatentStyleExceptionInfo() { Name = "Revision", UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo50 = new LatentStyleExceptionInfo() { Name = "List Paragraph", UiPriority = 34, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo51 = new LatentStyleExceptionInfo() { Name = "Quote", UiPriority = 29, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo52 = new LatentStyleExceptionInfo() { Name = "Intense Quote", UiPriority = 30, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo53 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 1", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo54 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 1", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo55 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 1", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo56 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 1", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo57 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 1", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo58 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 1", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo59 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 1", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo60 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 1", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo61 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 2", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo62 = new LatentStyleExceptionInfo() { Name = "Light List Accent 2", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo63 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 2", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo64 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 2", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo65 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 2", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo66 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 2", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo67 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 2", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo68 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 2", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo69 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 2", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo70 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 2", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo71 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 2", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo72 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 2", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo73 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 2", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo74 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 2", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo75 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 3", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo76 = new LatentStyleExceptionInfo() { Name = "Light List Accent 3", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo77 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 3", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo78 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 3", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo79 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 3", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo80 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 3", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo81 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 3", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo82 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 3", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo83 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 3", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo84 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 3", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo85 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 3", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo86 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 3", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo87 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 3", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo88 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 3", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo89 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 4", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo90 = new LatentStyleExceptionInfo() { Name = "Light List Accent 4", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo91 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 4", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo92 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 4", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo93 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 4", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo94 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 4", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo95 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 4", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo96 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 4", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo97 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 4", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo98 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 4", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo99 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 4", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo100 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 4", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo101 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 4", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo102 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 4", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo103 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 5", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo104 = new LatentStyleExceptionInfo() { Name = "Light List Accent 5", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo105 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 5", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo106 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 5", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo107 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 5", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo108 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 5", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo109 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 5", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo110 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 5", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo111 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 5", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo112 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 5", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo113 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 5", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo114 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 5", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo115 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 5", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo116 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 5", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo117 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 6", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo118 = new LatentStyleExceptionInfo() { Name = "Light List Accent 6", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo119 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 6", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo120 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 6", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo121 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 6", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo122 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 6", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo123 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 6", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo124 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 6", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo125 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 6", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo126 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 6", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo127 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 6", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo128 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 6", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo129 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 6", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo130 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 6", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo131 = new LatentStyleExceptionInfo() { Name = "Subtle Emphasis", UiPriority = 19, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo132 = new LatentStyleExceptionInfo() { Name = "Intense Emphasis", UiPriority = 21, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo133 = new LatentStyleExceptionInfo() { Name = "Subtle Reference", UiPriority = 31, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo134 = new LatentStyleExceptionInfo() { Name = "Intense Reference", UiPriority = 32, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo135 = new LatentStyleExceptionInfo() { Name = "Book Title", UiPriority = 33, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo136 = new LatentStyleExceptionInfo() { Name = "Bibliography", UiPriority = 37 };
      LatentStyleExceptionInfo latentStyleExceptionInfo137 = new LatentStyleExceptionInfo() { Name = "TOC Heading", UiPriority = 39, PrimaryStyle = true };

      latentStyles1.Append(latentStyleExceptionInfo1);
      latentStyles1.Append(latentStyleExceptionInfo2);
      latentStyles1.Append(latentStyleExceptionInfo3);
      latentStyles1.Append(latentStyleExceptionInfo4);
      latentStyles1.Append(latentStyleExceptionInfo5);
      latentStyles1.Append(latentStyleExceptionInfo6);
      latentStyles1.Append(latentStyleExceptionInfo7);
      latentStyles1.Append(latentStyleExceptionInfo8);
      latentStyles1.Append(latentStyleExceptionInfo9);
      latentStyles1.Append(latentStyleExceptionInfo10);
      latentStyles1.Append(latentStyleExceptionInfo11);
      latentStyles1.Append(latentStyleExceptionInfo12);
      latentStyles1.Append(latentStyleExceptionInfo13);
      latentStyles1.Append(latentStyleExceptionInfo14);
      latentStyles1.Append(latentStyleExceptionInfo15);
      latentStyles1.Append(latentStyleExceptionInfo16);
      latentStyles1.Append(latentStyleExceptionInfo17);
      latentStyles1.Append(latentStyleExceptionInfo18);
      latentStyles1.Append(latentStyleExceptionInfo19);
      latentStyles1.Append(latentStyleExceptionInfo20);
      latentStyles1.Append(latentStyleExceptionInfo21);
      latentStyles1.Append(latentStyleExceptionInfo22);
      latentStyles1.Append(latentStyleExceptionInfo23);
      latentStyles1.Append(latentStyleExceptionInfo24);
      latentStyles1.Append(latentStyleExceptionInfo25);
      latentStyles1.Append(latentStyleExceptionInfo26);
      latentStyles1.Append(latentStyleExceptionInfo27);
      latentStyles1.Append(latentStyleExceptionInfo28);
      latentStyles1.Append(latentStyleExceptionInfo29);
      latentStyles1.Append(latentStyleExceptionInfo30);
      latentStyles1.Append(latentStyleExceptionInfo31);
      latentStyles1.Append(latentStyleExceptionInfo32);
      latentStyles1.Append(latentStyleExceptionInfo33);
      latentStyles1.Append(latentStyleExceptionInfo34);
      latentStyles1.Append(latentStyleExceptionInfo35);
      latentStyles1.Append(latentStyleExceptionInfo36);
      latentStyles1.Append(latentStyleExceptionInfo37);
      latentStyles1.Append(latentStyleExceptionInfo38);
      latentStyles1.Append(latentStyleExceptionInfo39);
      latentStyles1.Append(latentStyleExceptionInfo40);
      latentStyles1.Append(latentStyleExceptionInfo41);
      latentStyles1.Append(latentStyleExceptionInfo42);
      latentStyles1.Append(latentStyleExceptionInfo43);
      latentStyles1.Append(latentStyleExceptionInfo44);
      latentStyles1.Append(latentStyleExceptionInfo45);
      latentStyles1.Append(latentStyleExceptionInfo46);
      latentStyles1.Append(latentStyleExceptionInfo47);
      latentStyles1.Append(latentStyleExceptionInfo48);
      latentStyles1.Append(latentStyleExceptionInfo49);
      latentStyles1.Append(latentStyleExceptionInfo50);
      latentStyles1.Append(latentStyleExceptionInfo51);
      latentStyles1.Append(latentStyleExceptionInfo52);
      latentStyles1.Append(latentStyleExceptionInfo53);
      latentStyles1.Append(latentStyleExceptionInfo54);
      latentStyles1.Append(latentStyleExceptionInfo55);
      latentStyles1.Append(latentStyleExceptionInfo56);
      latentStyles1.Append(latentStyleExceptionInfo57);
      latentStyles1.Append(latentStyleExceptionInfo58);
      latentStyles1.Append(latentStyleExceptionInfo59);
      latentStyles1.Append(latentStyleExceptionInfo60);
      latentStyles1.Append(latentStyleExceptionInfo61);
      latentStyles1.Append(latentStyleExceptionInfo62);
      latentStyles1.Append(latentStyleExceptionInfo63);
      latentStyles1.Append(latentStyleExceptionInfo64);
      latentStyles1.Append(latentStyleExceptionInfo65);
      latentStyles1.Append(latentStyleExceptionInfo66);
      latentStyles1.Append(latentStyleExceptionInfo67);
      latentStyles1.Append(latentStyleExceptionInfo68);
      latentStyles1.Append(latentStyleExceptionInfo69);
      latentStyles1.Append(latentStyleExceptionInfo70);
      latentStyles1.Append(latentStyleExceptionInfo71);
      latentStyles1.Append(latentStyleExceptionInfo72);
      latentStyles1.Append(latentStyleExceptionInfo73);
      latentStyles1.Append(latentStyleExceptionInfo74);
      latentStyles1.Append(latentStyleExceptionInfo75);
      latentStyles1.Append(latentStyleExceptionInfo76);
      latentStyles1.Append(latentStyleExceptionInfo77);
      latentStyles1.Append(latentStyleExceptionInfo78);
      latentStyles1.Append(latentStyleExceptionInfo79);
      latentStyles1.Append(latentStyleExceptionInfo80);
      latentStyles1.Append(latentStyleExceptionInfo81);
      latentStyles1.Append(latentStyleExceptionInfo82);
      latentStyles1.Append(latentStyleExceptionInfo83);
      latentStyles1.Append(latentStyleExceptionInfo84);
      latentStyles1.Append(latentStyleExceptionInfo85);
      latentStyles1.Append(latentStyleExceptionInfo86);
      latentStyles1.Append(latentStyleExceptionInfo87);
      latentStyles1.Append(latentStyleExceptionInfo88);
      latentStyles1.Append(latentStyleExceptionInfo89);
      latentStyles1.Append(latentStyleExceptionInfo90);
      latentStyles1.Append(latentStyleExceptionInfo91);
      latentStyles1.Append(latentStyleExceptionInfo92);
      latentStyles1.Append(latentStyleExceptionInfo93);
      latentStyles1.Append(latentStyleExceptionInfo94);
      latentStyles1.Append(latentStyleExceptionInfo95);
      latentStyles1.Append(latentStyleExceptionInfo96);
      latentStyles1.Append(latentStyleExceptionInfo97);
      latentStyles1.Append(latentStyleExceptionInfo98);
      latentStyles1.Append(latentStyleExceptionInfo99);
      latentStyles1.Append(latentStyleExceptionInfo100);
      latentStyles1.Append(latentStyleExceptionInfo101);
      latentStyles1.Append(latentStyleExceptionInfo102);
      latentStyles1.Append(latentStyleExceptionInfo103);
      latentStyles1.Append(latentStyleExceptionInfo104);
      latentStyles1.Append(latentStyleExceptionInfo105);
      latentStyles1.Append(latentStyleExceptionInfo106);
      latentStyles1.Append(latentStyleExceptionInfo107);
      latentStyles1.Append(latentStyleExceptionInfo108);
      latentStyles1.Append(latentStyleExceptionInfo109);
      latentStyles1.Append(latentStyleExceptionInfo110);
      latentStyles1.Append(latentStyleExceptionInfo111);
      latentStyles1.Append(latentStyleExceptionInfo112);
      latentStyles1.Append(latentStyleExceptionInfo113);
      latentStyles1.Append(latentStyleExceptionInfo114);
      latentStyles1.Append(latentStyleExceptionInfo115);
      latentStyles1.Append(latentStyleExceptionInfo116);
      latentStyles1.Append(latentStyleExceptionInfo117);
      latentStyles1.Append(latentStyleExceptionInfo118);
      latentStyles1.Append(latentStyleExceptionInfo119);
      latentStyles1.Append(latentStyleExceptionInfo120);
      latentStyles1.Append(latentStyleExceptionInfo121);
      latentStyles1.Append(latentStyleExceptionInfo122);
      latentStyles1.Append(latentStyleExceptionInfo123);
      latentStyles1.Append(latentStyleExceptionInfo124);
      latentStyles1.Append(latentStyleExceptionInfo125);
      latentStyles1.Append(latentStyleExceptionInfo126);
      latentStyles1.Append(latentStyleExceptionInfo127);
      latentStyles1.Append(latentStyleExceptionInfo128);
      latentStyles1.Append(latentStyleExceptionInfo129);
      latentStyles1.Append(latentStyleExceptionInfo130);
      latentStyles1.Append(latentStyleExceptionInfo131);
      latentStyles1.Append(latentStyleExceptionInfo132);
      latentStyles1.Append(latentStyleExceptionInfo133);
      latentStyles1.Append(latentStyleExceptionInfo134);
      latentStyles1.Append(latentStyleExceptionInfo135);
      latentStyles1.Append(latentStyleExceptionInfo136);
      latentStyles1.Append(latentStyleExceptionInfo137);

      Style style1 = new Style() { Type = StyleValues.Paragraph, StyleId = "Normal", Default = true };
      StyleName styleName1 = new StyleName() { Val = "Normal" };
      PrimaryStyle primaryStyle1 = new PrimaryStyle();

      style1.Append(styleName1);
      style1.Append(primaryStyle1);

      Style style2 = new Style() { Type = StyleValues.Paragraph, StyleId = "Heading1" };
      StyleName styleName2 = new StyleName() { Val = "heading 1" };
      BasedOn basedOn1 = new BasedOn() { Val = "Normal" };
      NextParagraphStyle nextParagraphStyle1 = new NextParagraphStyle() { Val = "Normal" };
      LinkedStyle linkedStyle1 = new LinkedStyle() { Val = "Heading1Char" };
      UIPriority uIPriority1 = new UIPriority() { Val = 9 };
      PrimaryStyle primaryStyle2 = new PrimaryStyle();
      Rsid rsid1 = new Rsid() { Val = "00146275" };

      StyleParagraphProperties styleParagraphProperties1 = new StyleParagraphProperties();
      KeepNext keepNext1 = new KeepNext();
      KeepLines keepLines1 = new KeepLines();
      SpacingBetweenLines spacingBetweenLines2 = new SpacingBetweenLines() { Before = "480", After = "0" };
      OutlineLevel outlineLevel1 = new OutlineLevel() { Val = 0 };

      styleParagraphProperties1.Append(keepNext1);
      styleParagraphProperties1.Append(keepLines1);
      styleParagraphProperties1.Append(spacingBetweenLines2);
      styleParagraphProperties1.Append(outlineLevel1);

      StyleRunProperties styleRunProperties1 = new StyleRunProperties();
      RunFonts runFonts3 = new RunFonts() { AsciiTheme = ThemeFontValues.MajorHighAnsi, HighAnsiTheme = ThemeFontValues.MajorHighAnsi, EastAsiaTheme = ThemeFontValues.MajorEastAsia, ComplexScriptTheme = ThemeFontValues.MajorBidi };
      Bold bold1 = new Bold();
      BoldComplexScript boldComplexScript1 = new BoldComplexScript();
      Color color1 = new Color() { Val = "365F91", ThemeColor = ThemeColorValues.Accent1, ThemeShade = "BF" };
      FontSize fontSize2 = new FontSize() { Val = "28" };
      FontSizeComplexScript fontSizeComplexScript2 = new FontSizeComplexScript() { Val = "28" };

      styleRunProperties1.Append(runFonts3);
      styleRunProperties1.Append(bold1);
      styleRunProperties1.Append(boldComplexScript1);
      styleRunProperties1.Append(color1);
      styleRunProperties1.Append(fontSize2);
      styleRunProperties1.Append(fontSizeComplexScript2);

      style2.Append(styleName2);
      style2.Append(basedOn1);
      style2.Append(nextParagraphStyle1);
      style2.Append(linkedStyle1);
      style2.Append(uIPriority1);
      style2.Append(primaryStyle2);
      style2.Append(rsid1);
      style2.Append(styleParagraphProperties1);
      style2.Append(styleRunProperties1);

      Style style3 = new Style() { Type = StyleValues.Character, StyleId = "DefaultParagraphFont", Default = true };
      StyleName styleName3 = new StyleName() { Val = "Default Paragraph Font" };
      UIPriority uIPriority2 = new UIPriority() { Val = 1 };
      SemiHidden semiHidden1 = new SemiHidden();
      UnhideWhenUsed unhideWhenUsed1 = new UnhideWhenUsed();

      style3.Append(styleName3);
      style3.Append(uIPriority2);
      style3.Append(semiHidden1);
      style3.Append(unhideWhenUsed1);

      Style style4 = new Style() { Type = StyleValues.Table, StyleId = "TableNormal", Default = true };
      StyleName styleName4 = new StyleName() { Val = "Normal Table" };
      UIPriority uIPriority3 = new UIPriority() { Val = 99 };
      SemiHidden semiHidden2 = new SemiHidden();
      UnhideWhenUsed unhideWhenUsed2 = new UnhideWhenUsed();

      StyleTableProperties styleTableProperties1 = new StyleTableProperties();
      TableIndentation tableIndentation1 = new TableIndentation() { Width = 0, Type = TableWidthUnitValues.Dxa };

      TableCellMarginDefault tableCellMarginDefault1 = new TableCellMarginDefault();
      TopMargin topMargin1 = new TopMargin() { Width = "0", Type = TableWidthUnitValues.Dxa };
      TableCellLeftMargin tableCellLeftMargin1 = new TableCellLeftMargin() { Width = 108, Type = TableWidthValues.Dxa };
      BottomMargin bottomMargin1 = new BottomMargin() { Width = "0", Type = TableWidthUnitValues.Dxa };
      TableCellRightMargin tableCellRightMargin1 = new TableCellRightMargin() { Width = 108, Type = TableWidthValues.Dxa };

      tableCellMarginDefault1.Append(topMargin1);
      tableCellMarginDefault1.Append(tableCellLeftMargin1);
      tableCellMarginDefault1.Append(bottomMargin1);
      tableCellMarginDefault1.Append(tableCellRightMargin1);

      styleTableProperties1.Append(tableIndentation1);
      styleTableProperties1.Append(tableCellMarginDefault1);

      style4.Append(styleName4);
      style4.Append(uIPriority3);
      style4.Append(semiHidden2);
      style4.Append(unhideWhenUsed2);
      style4.Append(styleTableProperties1);

      Style style5 = new Style() { Type = StyleValues.Numbering, StyleId = "NoList", Default = true };
      StyleName styleName5 = new StyleName() { Val = "No List" };
      UIPriority uIPriority4 = new UIPriority() { Val = 99 };
      SemiHidden semiHidden3 = new SemiHidden();
      UnhideWhenUsed unhideWhenUsed3 = new UnhideWhenUsed();

      style5.Append(styleName5);
      style5.Append(uIPriority4);
      style5.Append(semiHidden3);
      style5.Append(unhideWhenUsed3);

      Style style6 = new Style() { Type = StyleValues.Paragraph, StyleId = "Title" };
      StyleName styleName6 = new StyleName() { Val = "Title" };
      BasedOn basedOn2 = new BasedOn() { Val = "Normal" };
      NextParagraphStyle nextParagraphStyle2 = new NextParagraphStyle() { Val = "Normal" };
      LinkedStyle linkedStyle2 = new LinkedStyle() { Val = "TitleChar" };
      UIPriority uIPriority5 = new UIPriority() { Val = 10 };
      PrimaryStyle primaryStyle3 = new PrimaryStyle();
      Rsid rsid2 = new Rsid() { Val = "00146275" };

      StyleParagraphProperties styleParagraphProperties2 = new StyleParagraphProperties();

      ParagraphBorders paragraphBorders1 = new ParagraphBorders();
      BottomBorder bottomBorder1 = new BottomBorder() { Val = BorderValues.Single, Color = "4F81BD", ThemeColor = ThemeColorValues.Accent1, Size = (UInt32Value)8U, Space = (UInt32Value)4U };

      paragraphBorders1.Append(bottomBorder1);
      SpacingBetweenLines spacingBetweenLines3 = new SpacingBetweenLines() { After = "300", Line = "240", LineRule = LineSpacingRuleValues.Auto };
      ContextualSpacing contextualSpacing1 = new ContextualSpacing();

      styleParagraphProperties2.Append(paragraphBorders1);
      styleParagraphProperties2.Append(spacingBetweenLines3);
      styleParagraphProperties2.Append(contextualSpacing1);

      StyleRunProperties styleRunProperties2 = new StyleRunProperties();
      RunFonts runFonts4 = new RunFonts() { AsciiTheme = ThemeFontValues.MajorHighAnsi, HighAnsiTheme = ThemeFontValues.MajorHighAnsi, EastAsiaTheme = ThemeFontValues.MajorEastAsia, ComplexScriptTheme = ThemeFontValues.MajorBidi };
      Color color2 = new Color() { Val = "17365D", ThemeColor = ThemeColorValues.Text2, ThemeShade = "BF" };
      Spacing spacing1 = new Spacing() { Val = 5 };
      Kern kern1 = new Kern() { Val = (UInt32Value)28U };
      FontSize fontSize3 = new FontSize() { Val = "52" };
      FontSizeComplexScript fontSizeComplexScript3 = new FontSizeComplexScript() { Val = "52" };

      styleRunProperties2.Append(runFonts4);
      styleRunProperties2.Append(color2);
      styleRunProperties2.Append(spacing1);
      styleRunProperties2.Append(kern1);
      styleRunProperties2.Append(fontSize3);
      styleRunProperties2.Append(fontSizeComplexScript3);

      style6.Append(styleName6);
      style6.Append(basedOn2);
      style6.Append(nextParagraphStyle2);
      style6.Append(linkedStyle2);
      style6.Append(uIPriority5);
      style6.Append(primaryStyle3);
      style6.Append(rsid2);
      style6.Append(styleParagraphProperties2);
      style6.Append(styleRunProperties2);

      Style style7 = new Style() { Type = StyleValues.Character, StyleId = "TitleChar", CustomStyle = true };
      StyleName styleName7 = new StyleName() { Val = "Title Char" };
      BasedOn basedOn3 = new BasedOn() { Val = "DefaultParagraphFont" };
      LinkedStyle linkedStyle3 = new LinkedStyle() { Val = "Title" };
      UIPriority uIPriority6 = new UIPriority() { Val = 10 };
      Rsid rsid3 = new Rsid() { Val = "00146275" };

      StyleRunProperties styleRunProperties3 = new StyleRunProperties();
      RunFonts runFonts5 = new RunFonts() { AsciiTheme = ThemeFontValues.MajorHighAnsi, HighAnsiTheme = ThemeFontValues.MajorHighAnsi, EastAsiaTheme = ThemeFontValues.MajorEastAsia, ComplexScriptTheme = ThemeFontValues.MajorBidi };
      Color color3 = new Color() { Val = "17365D", ThemeColor = ThemeColorValues.Text2, ThemeShade = "BF" };
      Spacing spacing2 = new Spacing() { Val = 5 };
      Kern kern2 = new Kern() { Val = (UInt32Value)28U };
      FontSize fontSize4 = new FontSize() { Val = "52" };
      FontSizeComplexScript fontSizeComplexScript4 = new FontSizeComplexScript() { Val = "52" };

      styleRunProperties3.Append(runFonts5);
      styleRunProperties3.Append(color3);
      styleRunProperties3.Append(spacing2);
      styleRunProperties3.Append(kern2);
      styleRunProperties3.Append(fontSize4);
      styleRunProperties3.Append(fontSizeComplexScript4);

      style7.Append(styleName7);
      style7.Append(basedOn3);
      style7.Append(linkedStyle3);
      style7.Append(uIPriority6);
      style7.Append(rsid3);
      style7.Append(styleRunProperties3);

      Style style8 = new Style() { Type = StyleValues.Character, StyleId = "Heading1Char", CustomStyle = true };
      StyleName styleName8 = new StyleName() { Val = "Heading 1 Char" };
      BasedOn basedOn4 = new BasedOn() { Val = "DefaultParagraphFont" };
      LinkedStyle linkedStyle4 = new LinkedStyle() { Val = "Heading1" };
      UIPriority uIPriority7 = new UIPriority() { Val = 9 };
      Rsid rsid4 = new Rsid() { Val = "00146275" };

      StyleRunProperties styleRunProperties4 = new StyleRunProperties();
      RunFonts runFonts6 = new RunFonts() { AsciiTheme = ThemeFontValues.MajorHighAnsi, HighAnsiTheme = ThemeFontValues.MajorHighAnsi, EastAsiaTheme = ThemeFontValues.MajorEastAsia, ComplexScriptTheme = ThemeFontValues.MajorBidi };
      Bold bold2 = new Bold();
      BoldComplexScript boldComplexScript2 = new BoldComplexScript();
      Color color4 = new Color() { Val = "365F91", ThemeColor = ThemeColorValues.Accent1, ThemeShade = "BF" };
      FontSize fontSize5 = new FontSize() { Val = "28" };
      FontSizeComplexScript fontSizeComplexScript5 = new FontSizeComplexScript() { Val = "28" };

      styleRunProperties4.Append(runFonts6);
      styleRunProperties4.Append(bold2);
      styleRunProperties4.Append(boldComplexScript2);
      styleRunProperties4.Append(color4);
      styleRunProperties4.Append(fontSize5);
      styleRunProperties4.Append(fontSizeComplexScript5);

      style8.Append(styleName8);
      style8.Append(basedOn4);
      style8.Append(linkedStyle4);
      style8.Append(uIPriority7);
      style8.Append(rsid4);
      style8.Append(styleRunProperties4);

      Style style9 = new Style() { Type = StyleValues.Paragraph, StyleId = "ListParagraph" };
      StyleName styleName9 = new StyleName() { Val = "List Paragraph" };
      BasedOn basedOn5 = new BasedOn() { Val = "Normal" };
      UIPriority uIPriority8 = new UIPriority() { Val = 34 };
      PrimaryStyle primaryStyle4 = new PrimaryStyle();
      Rsid rsid5 = new Rsid() { Val = "00146275" };

      StyleParagraphProperties styleParagraphProperties3 = new StyleParagraphProperties();

      NumberingProperties numberingProperties1 = new NumberingProperties();
      NumberingId numberingId1 = new NumberingId() { Val = 3 };

      numberingProperties1.Append(numberingId1);
      ContextualSpacing contextualSpacing2 = new ContextualSpacing();

      styleParagraphProperties3.Append(numberingProperties1);
      styleParagraphProperties3.Append(contextualSpacing2);

      style9.Append(styleName9);
      style9.Append(basedOn5);
      style9.Append(uIPriority8);
      style9.Append(primaryStyle4);
      style9.Append(rsid5);
      style9.Append(styleParagraphProperties3);

      styles1.Append(docDefaults1);
      styles1.Append(latentStyles1);
      styles1.Append(style1);
      styles1.Append(style2);
      styles1.Append(style3);
      styles1.Append(style4);
      styles1.Append(style5);
      styles1.Append(style6);
      styles1.Append(style7);
      styles1.Append(style8);
      styles1.Append(style9);

      stylesWithEffectsPart1.Styles = styles1;
    }

    // Generates content of themePart1.
    private void GenerateThemePart1Content(ThemePart themePart1)
    {
      A.Theme theme1 = new A.Theme() { Name = "Office Theme" };
      theme1.AddNamespaceDeclaration("a", "http://schemas.openxmlformats.org/drawingml/2006/main");

      A.ThemeElements themeElements1 = new A.ThemeElements();

      A.ColorScheme colorScheme1 = new A.ColorScheme() { Name = "Office" };

      A.Dark1Color dark1Color1 = new A.Dark1Color();
      A.SystemColor systemColor1 = new A.SystemColor() { Val = A.SystemColorValues.WindowText, LastColor = "000000" };

      dark1Color1.Append(systemColor1);

      A.Light1Color light1Color1 = new A.Light1Color();
      A.SystemColor systemColor2 = new A.SystemColor() { Val = A.SystemColorValues.Window, LastColor = "FFFFFF" };

      light1Color1.Append(systemColor2);

      A.Dark2Color dark2Color1 = new A.Dark2Color();
      A.RgbColorModelHex rgbColorModelHex1 = new A.RgbColorModelHex() { Val = "1F497D" };

      dark2Color1.Append(rgbColorModelHex1);

      A.Light2Color light2Color1 = new A.Light2Color();
      A.RgbColorModelHex rgbColorModelHex2 = new A.RgbColorModelHex() { Val = "EEECE1" };

      light2Color1.Append(rgbColorModelHex2);

      A.Accent1Color accent1Color1 = new A.Accent1Color();
      A.RgbColorModelHex rgbColorModelHex3 = new A.RgbColorModelHex() { Val = "4F81BD" };

      accent1Color1.Append(rgbColorModelHex3);

      A.Accent2Color accent2Color1 = new A.Accent2Color();
      A.RgbColorModelHex rgbColorModelHex4 = new A.RgbColorModelHex() { Val = "C0504D" };

      accent2Color1.Append(rgbColorModelHex4);

      A.Accent3Color accent3Color1 = new A.Accent3Color();
      A.RgbColorModelHex rgbColorModelHex5 = new A.RgbColorModelHex() { Val = "9BBB59" };

      accent3Color1.Append(rgbColorModelHex5);

      A.Accent4Color accent4Color1 = new A.Accent4Color();
      A.RgbColorModelHex rgbColorModelHex6 = new A.RgbColorModelHex() { Val = "8064A2" };

      accent4Color1.Append(rgbColorModelHex6);

      A.Accent5Color accent5Color1 = new A.Accent5Color();
      A.RgbColorModelHex rgbColorModelHex7 = new A.RgbColorModelHex() { Val = "4BACC6" };

      accent5Color1.Append(rgbColorModelHex7);

      A.Accent6Color accent6Color1 = new A.Accent6Color();
      A.RgbColorModelHex rgbColorModelHex8 = new A.RgbColorModelHex() { Val = "F79646" };

      accent6Color1.Append(rgbColorModelHex8);

      A.Hyperlink hyperlink1 = new A.Hyperlink();
      A.RgbColorModelHex rgbColorModelHex9 = new A.RgbColorModelHex() { Val = "0000FF" };

      hyperlink1.Append(rgbColorModelHex9);

      A.FollowedHyperlinkColor followedHyperlinkColor1 = new A.FollowedHyperlinkColor();
      A.RgbColorModelHex rgbColorModelHex10 = new A.RgbColorModelHex() { Val = "800080" };

      followedHyperlinkColor1.Append(rgbColorModelHex10);

      colorScheme1.Append(dark1Color1);
      colorScheme1.Append(light1Color1);
      colorScheme1.Append(dark2Color1);
      colorScheme1.Append(light2Color1);
      colorScheme1.Append(accent1Color1);
      colorScheme1.Append(accent2Color1);
      colorScheme1.Append(accent3Color1);
      colorScheme1.Append(accent4Color1);
      colorScheme1.Append(accent5Color1);
      colorScheme1.Append(accent6Color1);
      colorScheme1.Append(hyperlink1);
      colorScheme1.Append(followedHyperlinkColor1);

      A.FontScheme fontScheme1 = new A.FontScheme() { Name = "Office" };

      A.MajorFont majorFont1 = new A.MajorFont();
      A.LatinFont latinFont1 = new A.LatinFont() { Typeface = "Cambria" };
      A.EastAsianFont eastAsianFont1 = new A.EastAsianFont() { Typeface = "" };
      A.ComplexScriptFont complexScriptFont1 = new A.ComplexScriptFont() { Typeface = "" };
      A.SupplementalFont supplementalFont1 = new A.SupplementalFont() { Script = "Jpan", Typeface = "ＭＳ ゴシック" };
      A.SupplementalFont supplementalFont2 = new A.SupplementalFont() { Script = "Hang", Typeface = "맑은 고딕" };
      A.SupplementalFont supplementalFont3 = new A.SupplementalFont() { Script = "Hans", Typeface = "宋体" };
      A.SupplementalFont supplementalFont4 = new A.SupplementalFont() { Script = "Hant", Typeface = "新細明體" };
      A.SupplementalFont supplementalFont5 = new A.SupplementalFont() { Script = "Arab", Typeface = "Times New Roman" };
      A.SupplementalFont supplementalFont6 = new A.SupplementalFont() { Script = "Hebr", Typeface = "Times New Roman" };
      A.SupplementalFont supplementalFont7 = new A.SupplementalFont() { Script = "Thai", Typeface = "Angsana New" };
      A.SupplementalFont supplementalFont8 = new A.SupplementalFont() { Script = "Ethi", Typeface = "Nyala" };
      A.SupplementalFont supplementalFont9 = new A.SupplementalFont() { Script = "Beng", Typeface = "Vrinda" };
      A.SupplementalFont supplementalFont10 = new A.SupplementalFont() { Script = "Gujr", Typeface = "Shruti" };
      A.SupplementalFont supplementalFont11 = new A.SupplementalFont() { Script = "Khmr", Typeface = "MoolBoran" };
      A.SupplementalFont supplementalFont12 = new A.SupplementalFont() { Script = "Knda", Typeface = "Tunga" };
      A.SupplementalFont supplementalFont13 = new A.SupplementalFont() { Script = "Guru", Typeface = "Raavi" };
      A.SupplementalFont supplementalFont14 = new A.SupplementalFont() { Script = "Cans", Typeface = "Euphemia" };
      A.SupplementalFont supplementalFont15 = new A.SupplementalFont() { Script = "Cher", Typeface = "Plantagenet Cherokee" };
      A.SupplementalFont supplementalFont16 = new A.SupplementalFont() { Script = "Yiii", Typeface = "Microsoft Yi Baiti" };
      A.SupplementalFont supplementalFont17 = new A.SupplementalFont() { Script = "Tibt", Typeface = "Microsoft Himalaya" };
      A.SupplementalFont supplementalFont18 = new A.SupplementalFont() { Script = "Thaa", Typeface = "MV Boli" };
      A.SupplementalFont supplementalFont19 = new A.SupplementalFont() { Script = "Deva", Typeface = "Mangal" };
      A.SupplementalFont supplementalFont20 = new A.SupplementalFont() { Script = "Telu", Typeface = "Gautami" };
      A.SupplementalFont supplementalFont21 = new A.SupplementalFont() { Script = "Taml", Typeface = "Latha" };
      A.SupplementalFont supplementalFont22 = new A.SupplementalFont() { Script = "Syrc", Typeface = "Estrangelo Edessa" };
      A.SupplementalFont supplementalFont23 = new A.SupplementalFont() { Script = "Orya", Typeface = "Kalinga" };
      A.SupplementalFont supplementalFont24 = new A.SupplementalFont() { Script = "Mlym", Typeface = "Kartika" };
      A.SupplementalFont supplementalFont25 = new A.SupplementalFont() { Script = "Laoo", Typeface = "DokChampa" };
      A.SupplementalFont supplementalFont26 = new A.SupplementalFont() { Script = "Sinh", Typeface = "Iskoola Pota" };
      A.SupplementalFont supplementalFont27 = new A.SupplementalFont() { Script = "Mong", Typeface = "Mongolian Baiti" };
      A.SupplementalFont supplementalFont28 = new A.SupplementalFont() { Script = "Viet", Typeface = "Times New Roman" };
      A.SupplementalFont supplementalFont29 = new A.SupplementalFont() { Script = "Uigh", Typeface = "Microsoft Uighur" };
      A.SupplementalFont supplementalFont30 = new A.SupplementalFont() { Script = "Geor", Typeface = "Sylfaen" };

      majorFont1.Append(latinFont1);
      majorFont1.Append(eastAsianFont1);
      majorFont1.Append(complexScriptFont1);
      majorFont1.Append(supplementalFont1);
      majorFont1.Append(supplementalFont2);
      majorFont1.Append(supplementalFont3);
      majorFont1.Append(supplementalFont4);
      majorFont1.Append(supplementalFont5);
      majorFont1.Append(supplementalFont6);
      majorFont1.Append(supplementalFont7);
      majorFont1.Append(supplementalFont8);
      majorFont1.Append(supplementalFont9);
      majorFont1.Append(supplementalFont10);
      majorFont1.Append(supplementalFont11);
      majorFont1.Append(supplementalFont12);
      majorFont1.Append(supplementalFont13);
      majorFont1.Append(supplementalFont14);
      majorFont1.Append(supplementalFont15);
      majorFont1.Append(supplementalFont16);
      majorFont1.Append(supplementalFont17);
      majorFont1.Append(supplementalFont18);
      majorFont1.Append(supplementalFont19);
      majorFont1.Append(supplementalFont20);
      majorFont1.Append(supplementalFont21);
      majorFont1.Append(supplementalFont22);
      majorFont1.Append(supplementalFont23);
      majorFont1.Append(supplementalFont24);
      majorFont1.Append(supplementalFont25);
      majorFont1.Append(supplementalFont26);
      majorFont1.Append(supplementalFont27);
      majorFont1.Append(supplementalFont28);
      majorFont1.Append(supplementalFont29);
      majorFont1.Append(supplementalFont30);

      A.MinorFont minorFont1 = new A.MinorFont();
      A.LatinFont latinFont2 = new A.LatinFont() { Typeface = "Calibri" };
      A.EastAsianFont eastAsianFont2 = new A.EastAsianFont() { Typeface = "" };
      A.ComplexScriptFont complexScriptFont2 = new A.ComplexScriptFont() { Typeface = "" };
      A.SupplementalFont supplementalFont31 = new A.SupplementalFont() { Script = "Jpan", Typeface = "ＭＳ 明朝" };
      A.SupplementalFont supplementalFont32 = new A.SupplementalFont() { Script = "Hang", Typeface = "맑은 고딕" };
      A.SupplementalFont supplementalFont33 = new A.SupplementalFont() { Script = "Hans", Typeface = "宋体" };
      A.SupplementalFont supplementalFont34 = new A.SupplementalFont() { Script = "Hant", Typeface = "新細明體" };
      A.SupplementalFont supplementalFont35 = new A.SupplementalFont() { Script = "Arab", Typeface = "Arial" };
      A.SupplementalFont supplementalFont36 = new A.SupplementalFont() { Script = "Hebr", Typeface = "Arial" };
      A.SupplementalFont supplementalFont37 = new A.SupplementalFont() { Script = "Thai", Typeface = "Cordia New" };
      A.SupplementalFont supplementalFont38 = new A.SupplementalFont() { Script = "Ethi", Typeface = "Nyala" };
      A.SupplementalFont supplementalFont39 = new A.SupplementalFont() { Script = "Beng", Typeface = "Vrinda" };
      A.SupplementalFont supplementalFont40 = new A.SupplementalFont() { Script = "Gujr", Typeface = "Shruti" };
      A.SupplementalFont supplementalFont41 = new A.SupplementalFont() { Script = "Khmr", Typeface = "DaunPenh" };
      A.SupplementalFont supplementalFont42 = new A.SupplementalFont() { Script = "Knda", Typeface = "Tunga" };
      A.SupplementalFont supplementalFont43 = new A.SupplementalFont() { Script = "Guru", Typeface = "Raavi" };
      A.SupplementalFont supplementalFont44 = new A.SupplementalFont() { Script = "Cans", Typeface = "Euphemia" };
      A.SupplementalFont supplementalFont45 = new A.SupplementalFont() { Script = "Cher", Typeface = "Plantagenet Cherokee" };
      A.SupplementalFont supplementalFont46 = new A.SupplementalFont() { Script = "Yiii", Typeface = "Microsoft Yi Baiti" };
      A.SupplementalFont supplementalFont47 = new A.SupplementalFont() { Script = "Tibt", Typeface = "Microsoft Himalaya" };
      A.SupplementalFont supplementalFont48 = new A.SupplementalFont() { Script = "Thaa", Typeface = "MV Boli" };
      A.SupplementalFont supplementalFont49 = new A.SupplementalFont() { Script = "Deva", Typeface = "Mangal" };
      A.SupplementalFont supplementalFont50 = new A.SupplementalFont() { Script = "Telu", Typeface = "Gautami" };
      A.SupplementalFont supplementalFont51 = new A.SupplementalFont() { Script = "Taml", Typeface = "Latha" };
      A.SupplementalFont supplementalFont52 = new A.SupplementalFont() { Script = "Syrc", Typeface = "Estrangelo Edessa" };
      A.SupplementalFont supplementalFont53 = new A.SupplementalFont() { Script = "Orya", Typeface = "Kalinga" };
      A.SupplementalFont supplementalFont54 = new A.SupplementalFont() { Script = "Mlym", Typeface = "Kartika" };
      A.SupplementalFont supplementalFont55 = new A.SupplementalFont() { Script = "Laoo", Typeface = "DokChampa" };
      A.SupplementalFont supplementalFont56 = new A.SupplementalFont() { Script = "Sinh", Typeface = "Iskoola Pota" };
      A.SupplementalFont supplementalFont57 = new A.SupplementalFont() { Script = "Mong", Typeface = "Mongolian Baiti" };
      A.SupplementalFont supplementalFont58 = new A.SupplementalFont() { Script = "Viet", Typeface = "Arial" };
      A.SupplementalFont supplementalFont59 = new A.SupplementalFont() { Script = "Uigh", Typeface = "Microsoft Uighur" };
      A.SupplementalFont supplementalFont60 = new A.SupplementalFont() { Script = "Geor", Typeface = "Sylfaen" };

      minorFont1.Append(latinFont2);
      minorFont1.Append(eastAsianFont2);
      minorFont1.Append(complexScriptFont2);
      minorFont1.Append(supplementalFont31);
      minorFont1.Append(supplementalFont32);
      minorFont1.Append(supplementalFont33);
      minorFont1.Append(supplementalFont34);
      minorFont1.Append(supplementalFont35);
      minorFont1.Append(supplementalFont36);
      minorFont1.Append(supplementalFont37);
      minorFont1.Append(supplementalFont38);
      minorFont1.Append(supplementalFont39);
      minorFont1.Append(supplementalFont40);
      minorFont1.Append(supplementalFont41);
      minorFont1.Append(supplementalFont42);
      minorFont1.Append(supplementalFont43);
      minorFont1.Append(supplementalFont44);
      minorFont1.Append(supplementalFont45);
      minorFont1.Append(supplementalFont46);
      minorFont1.Append(supplementalFont47);
      minorFont1.Append(supplementalFont48);
      minorFont1.Append(supplementalFont49);
      minorFont1.Append(supplementalFont50);
      minorFont1.Append(supplementalFont51);
      minorFont1.Append(supplementalFont52);
      minorFont1.Append(supplementalFont53);
      minorFont1.Append(supplementalFont54);
      minorFont1.Append(supplementalFont55);
      minorFont1.Append(supplementalFont56);
      minorFont1.Append(supplementalFont57);
      minorFont1.Append(supplementalFont58);
      minorFont1.Append(supplementalFont59);
      minorFont1.Append(supplementalFont60);

      fontScheme1.Append(majorFont1);
      fontScheme1.Append(minorFont1);

      A.FormatScheme formatScheme1 = new A.FormatScheme() { Name = "Office" };

      A.FillStyleList fillStyleList1 = new A.FillStyleList();

      A.SolidFill solidFill1 = new A.SolidFill();
      A.SchemeColor schemeColor1 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };

      solidFill1.Append(schemeColor1);

      A.GradientFill gradientFill1 = new A.GradientFill() { RotateWithShape = true };

      A.GradientStopList gradientStopList1 = new A.GradientStopList();

      A.GradientStop gradientStop1 = new A.GradientStop() { Position = 0 };

      A.SchemeColor schemeColor2 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Tint tint1 = new A.Tint() { Val = 50000 };
      A.SaturationModulation saturationModulation1 = new A.SaturationModulation() { Val = 300000 };

      schemeColor2.Append(tint1);
      schemeColor2.Append(saturationModulation1);

      gradientStop1.Append(schemeColor2);

      A.GradientStop gradientStop2 = new A.GradientStop() { Position = 35000 };

      A.SchemeColor schemeColor3 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Tint tint2 = new A.Tint() { Val = 37000 };
      A.SaturationModulation saturationModulation2 = new A.SaturationModulation() { Val = 300000 };

      schemeColor3.Append(tint2);
      schemeColor3.Append(saturationModulation2);

      gradientStop2.Append(schemeColor3);

      A.GradientStop gradientStop3 = new A.GradientStop() { Position = 100000 };

      A.SchemeColor schemeColor4 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Tint tint3 = new A.Tint() { Val = 15000 };
      A.SaturationModulation saturationModulation3 = new A.SaturationModulation() { Val = 350000 };

      schemeColor4.Append(tint3);
      schemeColor4.Append(saturationModulation3);

      gradientStop3.Append(schemeColor4);

      gradientStopList1.Append(gradientStop1);
      gradientStopList1.Append(gradientStop2);
      gradientStopList1.Append(gradientStop3);
      A.LinearGradientFill linearGradientFill1 = new A.LinearGradientFill() { Angle = 16200000, Scaled = true };

      gradientFill1.Append(gradientStopList1);
      gradientFill1.Append(linearGradientFill1);

      A.GradientFill gradientFill2 = new A.GradientFill() { RotateWithShape = true };

      A.GradientStopList gradientStopList2 = new A.GradientStopList();

      A.GradientStop gradientStop4 = new A.GradientStop() { Position = 0 };

      A.SchemeColor schemeColor5 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Shade shade1 = new A.Shade() { Val = 51000 };
      A.SaturationModulation saturationModulation4 = new A.SaturationModulation() { Val = 130000 };

      schemeColor5.Append(shade1);
      schemeColor5.Append(saturationModulation4);

      gradientStop4.Append(schemeColor5);

      A.GradientStop gradientStop5 = new A.GradientStop() { Position = 80000 };

      A.SchemeColor schemeColor6 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Shade shade2 = new A.Shade() { Val = 93000 };
      A.SaturationModulation saturationModulation5 = new A.SaturationModulation() { Val = 130000 };

      schemeColor6.Append(shade2);
      schemeColor6.Append(saturationModulation5);

      gradientStop5.Append(schemeColor6);

      A.GradientStop gradientStop6 = new A.GradientStop() { Position = 100000 };

      A.SchemeColor schemeColor7 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Shade shade3 = new A.Shade() { Val = 94000 };
      A.SaturationModulation saturationModulation6 = new A.SaturationModulation() { Val = 135000 };

      schemeColor7.Append(shade3);
      schemeColor7.Append(saturationModulation6);

      gradientStop6.Append(schemeColor7);

      gradientStopList2.Append(gradientStop4);
      gradientStopList2.Append(gradientStop5);
      gradientStopList2.Append(gradientStop6);
      A.LinearGradientFill linearGradientFill2 = new A.LinearGradientFill() { Angle = 16200000, Scaled = false };

      gradientFill2.Append(gradientStopList2);
      gradientFill2.Append(linearGradientFill2);

      fillStyleList1.Append(solidFill1);
      fillStyleList1.Append(gradientFill1);
      fillStyleList1.Append(gradientFill2);

      A.LineStyleList lineStyleList1 = new A.LineStyleList();

      A.Outline outline1 = new A.Outline() { Width = 9525, CapType = A.LineCapValues.Flat, CompoundLineType = A.CompoundLineValues.Single, Alignment = A.PenAlignmentValues.Center };

      A.SolidFill solidFill2 = new A.SolidFill();

      A.SchemeColor schemeColor8 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Shade shade4 = new A.Shade() { Val = 95000 };
      A.SaturationModulation saturationModulation7 = new A.SaturationModulation() { Val = 105000 };

      schemeColor8.Append(shade4);
      schemeColor8.Append(saturationModulation7);

      solidFill2.Append(schemeColor8);
      A.PresetDash presetDash1 = new A.PresetDash() { Val = A.PresetLineDashValues.Solid };

      outline1.Append(solidFill2);
      outline1.Append(presetDash1);

      A.Outline outline2 = new A.Outline() { Width = 25400, CapType = A.LineCapValues.Flat, CompoundLineType = A.CompoundLineValues.Single, Alignment = A.PenAlignmentValues.Center };

      A.SolidFill solidFill3 = new A.SolidFill();
      A.SchemeColor schemeColor9 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };

      solidFill3.Append(schemeColor9);
      A.PresetDash presetDash2 = new A.PresetDash() { Val = A.PresetLineDashValues.Solid };

      outline2.Append(solidFill3);
      outline2.Append(presetDash2);

      A.Outline outline3 = new A.Outline() { Width = 38100, CapType = A.LineCapValues.Flat, CompoundLineType = A.CompoundLineValues.Single, Alignment = A.PenAlignmentValues.Center };

      A.SolidFill solidFill4 = new A.SolidFill();
      A.SchemeColor schemeColor10 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };

      solidFill4.Append(schemeColor10);
      A.PresetDash presetDash3 = new A.PresetDash() { Val = A.PresetLineDashValues.Solid };

      outline3.Append(solidFill4);
      outline3.Append(presetDash3);

      lineStyleList1.Append(outline1);
      lineStyleList1.Append(outline2);
      lineStyleList1.Append(outline3);

      A.EffectStyleList effectStyleList1 = new A.EffectStyleList();

      A.EffectStyle effectStyle1 = new A.EffectStyle();

      A.EffectList effectList1 = new A.EffectList();

      A.OuterShadow outerShadow1 = new A.OuterShadow() { BlurRadius = 40000L, Distance = 20000L, Direction = 5400000, RotateWithShape = false };

      A.RgbColorModelHex rgbColorModelHex11 = new A.RgbColorModelHex() { Val = "000000" };
      A.Alpha alpha1 = new A.Alpha() { Val = 38000 };

      rgbColorModelHex11.Append(alpha1);

      outerShadow1.Append(rgbColorModelHex11);

      effectList1.Append(outerShadow1);

      effectStyle1.Append(effectList1);

      A.EffectStyle effectStyle2 = new A.EffectStyle();

      A.EffectList effectList2 = new A.EffectList();

      A.OuterShadow outerShadow2 = new A.OuterShadow() { BlurRadius = 40000L, Distance = 23000L, Direction = 5400000, RotateWithShape = false };

      A.RgbColorModelHex rgbColorModelHex12 = new A.RgbColorModelHex() { Val = "000000" };
      A.Alpha alpha2 = new A.Alpha() { Val = 35000 };

      rgbColorModelHex12.Append(alpha2);

      outerShadow2.Append(rgbColorModelHex12);

      effectList2.Append(outerShadow2);

      effectStyle2.Append(effectList2);

      A.EffectStyle effectStyle3 = new A.EffectStyle();

      A.EffectList effectList3 = new A.EffectList();

      A.OuterShadow outerShadow3 = new A.OuterShadow() { BlurRadius = 40000L, Distance = 23000L, Direction = 5400000, RotateWithShape = false };

      A.RgbColorModelHex rgbColorModelHex13 = new A.RgbColorModelHex() { Val = "000000" };
      A.Alpha alpha3 = new A.Alpha() { Val = 35000 };

      rgbColorModelHex13.Append(alpha3);

      outerShadow3.Append(rgbColorModelHex13);

      effectList3.Append(outerShadow3);

      A.Scene3DType scene3DType1 = new A.Scene3DType();

      A.Camera camera1 = new A.Camera() { Preset = A.PresetCameraValues.OrthographicFront };
      A.Rotation rotation1 = new A.Rotation() { Latitude = 0, Longitude = 0, Revolution = 0 };

      camera1.Append(rotation1);

      A.LightRig lightRig1 = new A.LightRig() { Rig = A.LightRigValues.ThreePoints, Direction = A.LightRigDirectionValues.Top };
      A.Rotation rotation2 = new A.Rotation() { Latitude = 0, Longitude = 0, Revolution = 1200000 };

      lightRig1.Append(rotation2);

      scene3DType1.Append(camera1);
      scene3DType1.Append(lightRig1);

      A.Shape3DType shape3DType1 = new A.Shape3DType();
      A.BevelTop bevelTop1 = new A.BevelTop() { Width = 63500L, Height = 25400L };

      shape3DType1.Append(bevelTop1);

      effectStyle3.Append(effectList3);
      effectStyle3.Append(scene3DType1);
      effectStyle3.Append(shape3DType1);

      effectStyleList1.Append(effectStyle1);
      effectStyleList1.Append(effectStyle2);
      effectStyleList1.Append(effectStyle3);

      A.BackgroundFillStyleList backgroundFillStyleList1 = new A.BackgroundFillStyleList();

      A.SolidFill solidFill5 = new A.SolidFill();
      A.SchemeColor schemeColor11 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };

      solidFill5.Append(schemeColor11);

      A.GradientFill gradientFill3 = new A.GradientFill() { RotateWithShape = true };

      A.GradientStopList gradientStopList3 = new A.GradientStopList();

      A.GradientStop gradientStop7 = new A.GradientStop() { Position = 0 };

      A.SchemeColor schemeColor12 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Tint tint4 = new A.Tint() { Val = 40000 };
      A.SaturationModulation saturationModulation8 = new A.SaturationModulation() { Val = 350000 };

      schemeColor12.Append(tint4);
      schemeColor12.Append(saturationModulation8);

      gradientStop7.Append(schemeColor12);

      A.GradientStop gradientStop8 = new A.GradientStop() { Position = 40000 };

      A.SchemeColor schemeColor13 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Tint tint5 = new A.Tint() { Val = 45000 };
      A.Shade shade5 = new A.Shade() { Val = 99000 };
      A.SaturationModulation saturationModulation9 = new A.SaturationModulation() { Val = 350000 };

      schemeColor13.Append(tint5);
      schemeColor13.Append(shade5);
      schemeColor13.Append(saturationModulation9);

      gradientStop8.Append(schemeColor13);

      A.GradientStop gradientStop9 = new A.GradientStop() { Position = 100000 };

      A.SchemeColor schemeColor14 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Shade shade6 = new A.Shade() { Val = 20000 };
      A.SaturationModulation saturationModulation10 = new A.SaturationModulation() { Val = 255000 };

      schemeColor14.Append(shade6);
      schemeColor14.Append(saturationModulation10);

      gradientStop9.Append(schemeColor14);

      gradientStopList3.Append(gradientStop7);
      gradientStopList3.Append(gradientStop8);
      gradientStopList3.Append(gradientStop9);

      A.PathGradientFill pathGradientFill1 = new A.PathGradientFill() { Path = A.PathShadeValues.Circle };
      A.FillToRectangle fillToRectangle1 = new A.FillToRectangle() { Left = 50000, Top = -80000, Right = 50000, Bottom = 180000 };

      pathGradientFill1.Append(fillToRectangle1);

      gradientFill3.Append(gradientStopList3);
      gradientFill3.Append(pathGradientFill1);

      A.GradientFill gradientFill4 = new A.GradientFill() { RotateWithShape = true };

      A.GradientStopList gradientStopList4 = new A.GradientStopList();

      A.GradientStop gradientStop10 = new A.GradientStop() { Position = 0 };

      A.SchemeColor schemeColor15 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Tint tint6 = new A.Tint() { Val = 80000 };
      A.SaturationModulation saturationModulation11 = new A.SaturationModulation() { Val = 300000 };

      schemeColor15.Append(tint6);
      schemeColor15.Append(saturationModulation11);

      gradientStop10.Append(schemeColor15);

      A.GradientStop gradientStop11 = new A.GradientStop() { Position = 100000 };

      A.SchemeColor schemeColor16 = new A.SchemeColor() { Val = A.SchemeColorValues.PhColor };
      A.Shade shade7 = new A.Shade() { Val = 30000 };
      A.SaturationModulation saturationModulation12 = new A.SaturationModulation() { Val = 200000 };

      schemeColor16.Append(shade7);
      schemeColor16.Append(saturationModulation12);

      gradientStop11.Append(schemeColor16);

      gradientStopList4.Append(gradientStop10);
      gradientStopList4.Append(gradientStop11);

      A.PathGradientFill pathGradientFill2 = new A.PathGradientFill() { Path = A.PathShadeValues.Circle };
      A.FillToRectangle fillToRectangle2 = new A.FillToRectangle() { Left = 50000, Top = 50000, Right = 50000, Bottom = 50000 };

      pathGradientFill2.Append(fillToRectangle2);

      gradientFill4.Append(gradientStopList4);
      gradientFill4.Append(pathGradientFill2);

      backgroundFillStyleList1.Append(solidFill5);
      backgroundFillStyleList1.Append(gradientFill3);
      backgroundFillStyleList1.Append(gradientFill4);

      formatScheme1.Append(fillStyleList1);
      formatScheme1.Append(lineStyleList1);
      formatScheme1.Append(effectStyleList1);
      formatScheme1.Append(backgroundFillStyleList1);

      themeElements1.Append(colorScheme1);
      themeElements1.Append(fontScheme1);
      themeElements1.Append(formatScheme1);
      A.ObjectDefaults objectDefaults1 = new A.ObjectDefaults();
      A.ExtraColorSchemeList extraColorSchemeList1 = new A.ExtraColorSchemeList();

      theme1.Append(themeElements1);
      theme1.Append(objectDefaults1);
      theme1.Append(extraColorSchemeList1);

      themePart1.Theme = theme1;
    }

    // Generates content of styleDefinitionsPart1.
    private void GenerateStyleDefinitionsPart1Content(StyleDefinitionsPart styleDefinitionsPart1)
    {
      Styles styles2 = new Styles() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14" } };
      styles2.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
      styles2.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
      styles2.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
      styles2.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");

      DocDefaults docDefaults2 = new DocDefaults();

      RunPropertiesDefault runPropertiesDefault2 = new RunPropertiesDefault();

      RunPropertiesBaseStyle runPropertiesBaseStyle2 = new RunPropertiesBaseStyle();
      RunFonts runFonts7 = new RunFonts() { AsciiTheme = ThemeFontValues.MinorHighAnsi, HighAnsiTheme = ThemeFontValues.MinorHighAnsi, EastAsiaTheme = ThemeFontValues.MinorHighAnsi, ComplexScriptTheme = ThemeFontValues.MinorBidi };
      FontSize fontSize6 = new FontSize() { Val = "22" };
      FontSizeComplexScript fontSizeComplexScript6 = new FontSizeComplexScript() { Val = "22" };
      Languages languages2 = new Languages() { Val = "en-AU", EastAsia = "en-AU", Bidi = "ar-SA" };

      runPropertiesBaseStyle2.Append(runFonts7);
      runPropertiesBaseStyle2.Append(fontSize6);
      runPropertiesBaseStyle2.Append(fontSizeComplexScript6);
      runPropertiesBaseStyle2.Append(languages2);

      runPropertiesDefault2.Append(runPropertiesBaseStyle2);

      ParagraphPropertiesDefault paragraphPropertiesDefault2 = new ParagraphPropertiesDefault();

      ParagraphPropertiesBaseStyle paragraphPropertiesBaseStyle2 = new ParagraphPropertiesBaseStyle();
      SpacingBetweenLines spacingBetweenLines4 = new SpacingBetweenLines() { After = "200", Line = "276", LineRule = LineSpacingRuleValues.Auto };

      paragraphPropertiesBaseStyle2.Append(spacingBetweenLines4);

      paragraphPropertiesDefault2.Append(paragraphPropertiesBaseStyle2);

      docDefaults2.Append(runPropertiesDefault2);
      docDefaults2.Append(paragraphPropertiesDefault2);

      LatentStyles latentStyles2 = new LatentStyles() { DefaultLockedState = false, DefaultUiPriority = 99, DefaultSemiHidden = true, DefaultUnhideWhenUsed = true, DefaultPrimaryStyle = false, Count = 267 };
      LatentStyleExceptionInfo latentStyleExceptionInfo138 = new LatentStyleExceptionInfo() { Name = "Normal", UiPriority = 0, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo139 = new LatentStyleExceptionInfo() { Name = "heading 1", UiPriority = 9, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo140 = new LatentStyleExceptionInfo() { Name = "heading 2", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo141 = new LatentStyleExceptionInfo() { Name = "heading 3", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo142 = new LatentStyleExceptionInfo() { Name = "heading 4", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo143 = new LatentStyleExceptionInfo() { Name = "heading 5", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo144 = new LatentStyleExceptionInfo() { Name = "heading 6", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo145 = new LatentStyleExceptionInfo() { Name = "heading 7", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo146 = new LatentStyleExceptionInfo() { Name = "heading 8", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo147 = new LatentStyleExceptionInfo() { Name = "heading 9", UiPriority = 9, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo148 = new LatentStyleExceptionInfo() { Name = "toc 1", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo149 = new LatentStyleExceptionInfo() { Name = "toc 2", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo150 = new LatentStyleExceptionInfo() { Name = "toc 3", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo151 = new LatentStyleExceptionInfo() { Name = "toc 4", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo152 = new LatentStyleExceptionInfo() { Name = "toc 5", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo153 = new LatentStyleExceptionInfo() { Name = "toc 6", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo154 = new LatentStyleExceptionInfo() { Name = "toc 7", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo155 = new LatentStyleExceptionInfo() { Name = "toc 8", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo156 = new LatentStyleExceptionInfo() { Name = "toc 9", UiPriority = 39 };
      LatentStyleExceptionInfo latentStyleExceptionInfo157 = new LatentStyleExceptionInfo() { Name = "caption", UiPriority = 35, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo158 = new LatentStyleExceptionInfo() { Name = "Title", UiPriority = 10, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo159 = new LatentStyleExceptionInfo() { Name = "Default Paragraph Font", UiPriority = 1 };
      LatentStyleExceptionInfo latentStyleExceptionInfo160 = new LatentStyleExceptionInfo() { Name = "Subtitle", UiPriority = 11, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo161 = new LatentStyleExceptionInfo() { Name = "Strong", UiPriority = 22, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo162 = new LatentStyleExceptionInfo() { Name = "Emphasis", UiPriority = 20, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo163 = new LatentStyleExceptionInfo() { Name = "Table Grid", UiPriority = 59, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo164 = new LatentStyleExceptionInfo() { Name = "Placeholder Text", UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo165 = new LatentStyleExceptionInfo() { Name = "No Spacing", UiPriority = 1, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo166 = new LatentStyleExceptionInfo() { Name = "Light Shading", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo167 = new LatentStyleExceptionInfo() { Name = "Light List", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo168 = new LatentStyleExceptionInfo() { Name = "Light Grid", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo169 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo170 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo171 = new LatentStyleExceptionInfo() { Name = "Medium List 1", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo172 = new LatentStyleExceptionInfo() { Name = "Medium List 2", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo173 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo174 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo175 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo176 = new LatentStyleExceptionInfo() { Name = "Dark List", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo177 = new LatentStyleExceptionInfo() { Name = "Colorful Shading", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo178 = new LatentStyleExceptionInfo() { Name = "Colorful List", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo179 = new LatentStyleExceptionInfo() { Name = "Colorful Grid", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo180 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 1", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo181 = new LatentStyleExceptionInfo() { Name = "Light List Accent 1", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo182 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 1", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo183 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 1", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo184 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 1", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo185 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 1", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo186 = new LatentStyleExceptionInfo() { Name = "Revision", UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo187 = new LatentStyleExceptionInfo() { Name = "List Paragraph", UiPriority = 34, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo188 = new LatentStyleExceptionInfo() { Name = "Quote", UiPriority = 29, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo189 = new LatentStyleExceptionInfo() { Name = "Intense Quote", UiPriority = 30, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo190 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 1", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo191 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 1", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo192 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 1", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo193 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 1", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo194 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 1", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo195 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 1", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo196 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 1", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo197 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 1", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo198 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 2", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo199 = new LatentStyleExceptionInfo() { Name = "Light List Accent 2", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo200 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 2", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo201 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 2", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo202 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 2", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo203 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 2", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo204 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 2", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo205 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 2", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo206 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 2", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo207 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 2", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo208 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 2", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo209 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 2", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo210 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 2", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo211 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 2", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo212 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 3", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo213 = new LatentStyleExceptionInfo() { Name = "Light List Accent 3", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo214 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 3", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo215 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 3", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo216 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 3", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo217 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 3", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo218 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 3", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo219 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 3", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo220 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 3", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo221 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 3", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo222 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 3", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo223 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 3", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo224 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 3", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo225 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 3", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo226 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 4", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo227 = new LatentStyleExceptionInfo() { Name = "Light List Accent 4", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo228 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 4", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo229 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 4", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo230 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 4", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo231 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 4", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo232 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 4", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo233 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 4", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo234 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 4", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo235 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 4", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo236 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 4", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo237 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 4", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo238 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 4", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo239 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 4", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo240 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 5", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo241 = new LatentStyleExceptionInfo() { Name = "Light List Accent 5", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo242 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 5", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo243 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 5", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo244 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 5", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo245 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 5", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo246 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 5", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo247 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 5", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo248 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 5", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo249 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 5", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo250 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 5", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo251 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 5", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo252 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 5", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo253 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 5", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo254 = new LatentStyleExceptionInfo() { Name = "Light Shading Accent 6", UiPriority = 60, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo255 = new LatentStyleExceptionInfo() { Name = "Light List Accent 6", UiPriority = 61, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo256 = new LatentStyleExceptionInfo() { Name = "Light Grid Accent 6", UiPriority = 62, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo257 = new LatentStyleExceptionInfo() { Name = "Medium Shading 1 Accent 6", UiPriority = 63, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo258 = new LatentStyleExceptionInfo() { Name = "Medium Shading 2 Accent 6", UiPriority = 64, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo259 = new LatentStyleExceptionInfo() { Name = "Medium List 1 Accent 6", UiPriority = 65, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo260 = new LatentStyleExceptionInfo() { Name = "Medium List 2 Accent 6", UiPriority = 66, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo261 = new LatentStyleExceptionInfo() { Name = "Medium Grid 1 Accent 6", UiPriority = 67, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo262 = new LatentStyleExceptionInfo() { Name = "Medium Grid 2 Accent 6", UiPriority = 68, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo263 = new LatentStyleExceptionInfo() { Name = "Medium Grid 3 Accent 6", UiPriority = 69, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo264 = new LatentStyleExceptionInfo() { Name = "Dark List Accent 6", UiPriority = 70, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo265 = new LatentStyleExceptionInfo() { Name = "Colorful Shading Accent 6", UiPriority = 71, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo266 = new LatentStyleExceptionInfo() { Name = "Colorful List Accent 6", UiPriority = 72, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo267 = new LatentStyleExceptionInfo() { Name = "Colorful Grid Accent 6", UiPriority = 73, SemiHidden = false, UnhideWhenUsed = false };
      LatentStyleExceptionInfo latentStyleExceptionInfo268 = new LatentStyleExceptionInfo() { Name = "Subtle Emphasis", UiPriority = 19, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo269 = new LatentStyleExceptionInfo() { Name = "Intense Emphasis", UiPriority = 21, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo270 = new LatentStyleExceptionInfo() { Name = "Subtle Reference", UiPriority = 31, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo271 = new LatentStyleExceptionInfo() { Name = "Intense Reference", UiPriority = 32, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo272 = new LatentStyleExceptionInfo() { Name = "Book Title", UiPriority = 33, SemiHidden = false, UnhideWhenUsed = false, PrimaryStyle = true };
      LatentStyleExceptionInfo latentStyleExceptionInfo273 = new LatentStyleExceptionInfo() { Name = "Bibliography", UiPriority = 37 };
      LatentStyleExceptionInfo latentStyleExceptionInfo274 = new LatentStyleExceptionInfo() { Name = "TOC Heading", UiPriority = 39, PrimaryStyle = true };

      latentStyles2.Append(latentStyleExceptionInfo138);
      latentStyles2.Append(latentStyleExceptionInfo139);
      latentStyles2.Append(latentStyleExceptionInfo140);
      latentStyles2.Append(latentStyleExceptionInfo141);
      latentStyles2.Append(latentStyleExceptionInfo142);
      latentStyles2.Append(latentStyleExceptionInfo143);
      latentStyles2.Append(latentStyleExceptionInfo144);
      latentStyles2.Append(latentStyleExceptionInfo145);
      latentStyles2.Append(latentStyleExceptionInfo146);
      latentStyles2.Append(latentStyleExceptionInfo147);
      latentStyles2.Append(latentStyleExceptionInfo148);
      latentStyles2.Append(latentStyleExceptionInfo149);
      latentStyles2.Append(latentStyleExceptionInfo150);
      latentStyles2.Append(latentStyleExceptionInfo151);
      latentStyles2.Append(latentStyleExceptionInfo152);
      latentStyles2.Append(latentStyleExceptionInfo153);
      latentStyles2.Append(latentStyleExceptionInfo154);
      latentStyles2.Append(latentStyleExceptionInfo155);
      latentStyles2.Append(latentStyleExceptionInfo156);
      latentStyles2.Append(latentStyleExceptionInfo157);
      latentStyles2.Append(latentStyleExceptionInfo158);
      latentStyles2.Append(latentStyleExceptionInfo159);
      latentStyles2.Append(latentStyleExceptionInfo160);
      latentStyles2.Append(latentStyleExceptionInfo161);
      latentStyles2.Append(latentStyleExceptionInfo162);
      latentStyles2.Append(latentStyleExceptionInfo163);
      latentStyles2.Append(latentStyleExceptionInfo164);
      latentStyles2.Append(latentStyleExceptionInfo165);
      latentStyles2.Append(latentStyleExceptionInfo166);
      latentStyles2.Append(latentStyleExceptionInfo167);
      latentStyles2.Append(latentStyleExceptionInfo168);
      latentStyles2.Append(latentStyleExceptionInfo169);
      latentStyles2.Append(latentStyleExceptionInfo170);
      latentStyles2.Append(latentStyleExceptionInfo171);
      latentStyles2.Append(latentStyleExceptionInfo172);
      latentStyles2.Append(latentStyleExceptionInfo173);
      latentStyles2.Append(latentStyleExceptionInfo174);
      latentStyles2.Append(latentStyleExceptionInfo175);
      latentStyles2.Append(latentStyleExceptionInfo176);
      latentStyles2.Append(latentStyleExceptionInfo177);
      latentStyles2.Append(latentStyleExceptionInfo178);
      latentStyles2.Append(latentStyleExceptionInfo179);
      latentStyles2.Append(latentStyleExceptionInfo180);
      latentStyles2.Append(latentStyleExceptionInfo181);
      latentStyles2.Append(latentStyleExceptionInfo182);
      latentStyles2.Append(latentStyleExceptionInfo183);
      latentStyles2.Append(latentStyleExceptionInfo184);
      latentStyles2.Append(latentStyleExceptionInfo185);
      latentStyles2.Append(latentStyleExceptionInfo186);
      latentStyles2.Append(latentStyleExceptionInfo187);
      latentStyles2.Append(latentStyleExceptionInfo188);
      latentStyles2.Append(latentStyleExceptionInfo189);
      latentStyles2.Append(latentStyleExceptionInfo190);
      latentStyles2.Append(latentStyleExceptionInfo191);
      latentStyles2.Append(latentStyleExceptionInfo192);
      latentStyles2.Append(latentStyleExceptionInfo193);
      latentStyles2.Append(latentStyleExceptionInfo194);
      latentStyles2.Append(latentStyleExceptionInfo195);
      latentStyles2.Append(latentStyleExceptionInfo196);
      latentStyles2.Append(latentStyleExceptionInfo197);
      latentStyles2.Append(latentStyleExceptionInfo198);
      latentStyles2.Append(latentStyleExceptionInfo199);
      latentStyles2.Append(latentStyleExceptionInfo200);
      latentStyles2.Append(latentStyleExceptionInfo201);
      latentStyles2.Append(latentStyleExceptionInfo202);
      latentStyles2.Append(latentStyleExceptionInfo203);
      latentStyles2.Append(latentStyleExceptionInfo204);
      latentStyles2.Append(latentStyleExceptionInfo205);
      latentStyles2.Append(latentStyleExceptionInfo206);
      latentStyles2.Append(latentStyleExceptionInfo207);
      latentStyles2.Append(latentStyleExceptionInfo208);
      latentStyles2.Append(latentStyleExceptionInfo209);
      latentStyles2.Append(latentStyleExceptionInfo210);
      latentStyles2.Append(latentStyleExceptionInfo211);
      latentStyles2.Append(latentStyleExceptionInfo212);
      latentStyles2.Append(latentStyleExceptionInfo213);
      latentStyles2.Append(latentStyleExceptionInfo214);
      latentStyles2.Append(latentStyleExceptionInfo215);
      latentStyles2.Append(latentStyleExceptionInfo216);
      latentStyles2.Append(latentStyleExceptionInfo217);
      latentStyles2.Append(latentStyleExceptionInfo218);
      latentStyles2.Append(latentStyleExceptionInfo219);
      latentStyles2.Append(latentStyleExceptionInfo220);
      latentStyles2.Append(latentStyleExceptionInfo221);
      latentStyles2.Append(latentStyleExceptionInfo222);
      latentStyles2.Append(latentStyleExceptionInfo223);
      latentStyles2.Append(latentStyleExceptionInfo224);
      latentStyles2.Append(latentStyleExceptionInfo225);
      latentStyles2.Append(latentStyleExceptionInfo226);
      latentStyles2.Append(latentStyleExceptionInfo227);
      latentStyles2.Append(latentStyleExceptionInfo228);
      latentStyles2.Append(latentStyleExceptionInfo229);
      latentStyles2.Append(latentStyleExceptionInfo230);
      latentStyles2.Append(latentStyleExceptionInfo231);
      latentStyles2.Append(latentStyleExceptionInfo232);
      latentStyles2.Append(latentStyleExceptionInfo233);
      latentStyles2.Append(latentStyleExceptionInfo234);
      latentStyles2.Append(latentStyleExceptionInfo235);
      latentStyles2.Append(latentStyleExceptionInfo236);
      latentStyles2.Append(latentStyleExceptionInfo237);
      latentStyles2.Append(latentStyleExceptionInfo238);
      latentStyles2.Append(latentStyleExceptionInfo239);
      latentStyles2.Append(latentStyleExceptionInfo240);
      latentStyles2.Append(latentStyleExceptionInfo241);
      latentStyles2.Append(latentStyleExceptionInfo242);
      latentStyles2.Append(latentStyleExceptionInfo243);
      latentStyles2.Append(latentStyleExceptionInfo244);
      latentStyles2.Append(latentStyleExceptionInfo245);
      latentStyles2.Append(latentStyleExceptionInfo246);
      latentStyles2.Append(latentStyleExceptionInfo247);
      latentStyles2.Append(latentStyleExceptionInfo248);
      latentStyles2.Append(latentStyleExceptionInfo249);
      latentStyles2.Append(latentStyleExceptionInfo250);
      latentStyles2.Append(latentStyleExceptionInfo251);
      latentStyles2.Append(latentStyleExceptionInfo252);
      latentStyles2.Append(latentStyleExceptionInfo253);
      latentStyles2.Append(latentStyleExceptionInfo254);
      latentStyles2.Append(latentStyleExceptionInfo255);
      latentStyles2.Append(latentStyleExceptionInfo256);
      latentStyles2.Append(latentStyleExceptionInfo257);
      latentStyles2.Append(latentStyleExceptionInfo258);
      latentStyles2.Append(latentStyleExceptionInfo259);
      latentStyles2.Append(latentStyleExceptionInfo260);
      latentStyles2.Append(latentStyleExceptionInfo261);
      latentStyles2.Append(latentStyleExceptionInfo262);
      latentStyles2.Append(latentStyleExceptionInfo263);
      latentStyles2.Append(latentStyleExceptionInfo264);
      latentStyles2.Append(latentStyleExceptionInfo265);
      latentStyles2.Append(latentStyleExceptionInfo266);
      latentStyles2.Append(latentStyleExceptionInfo267);
      latentStyles2.Append(latentStyleExceptionInfo268);
      latentStyles2.Append(latentStyleExceptionInfo269);
      latentStyles2.Append(latentStyleExceptionInfo270);
      latentStyles2.Append(latentStyleExceptionInfo271);
      latentStyles2.Append(latentStyleExceptionInfo272);
      latentStyles2.Append(latentStyleExceptionInfo273);
      latentStyles2.Append(latentStyleExceptionInfo274);

      Style style10 = new Style() { Type = StyleValues.Paragraph, StyleId = "Normal", Default = true };
      StyleName styleName10 = new StyleName() { Val = "Normal" };
      PrimaryStyle primaryStyle5 = new PrimaryStyle();

      style10.Append(styleName10);
      style10.Append(primaryStyle5);

      Style style11 = new Style() { Type = StyleValues.Paragraph, StyleId = "Heading1" };
      StyleName styleName11 = new StyleName() { Val = "heading 1" };
      BasedOn basedOn6 = new BasedOn() { Val = "Normal" };
      NextParagraphStyle nextParagraphStyle3 = new NextParagraphStyle() { Val = "Normal" };
      LinkedStyle linkedStyle5 = new LinkedStyle() { Val = "Heading1Char" };
      UIPriority uIPriority9 = new UIPriority() { Val = 9 };
      PrimaryStyle primaryStyle6 = new PrimaryStyle();
      Rsid rsid6 = new Rsid() { Val = "00146275" };

      StyleParagraphProperties styleParagraphProperties4 = new StyleParagraphProperties();
      KeepNext keepNext2 = new KeepNext();
      KeepLines keepLines2 = new KeepLines();
      SpacingBetweenLines spacingBetweenLines5 = new SpacingBetweenLines() { Before = "480", After = "0" };
      OutlineLevel outlineLevel2 = new OutlineLevel() { Val = 0 };

      styleParagraphProperties4.Append(keepNext2);
      styleParagraphProperties4.Append(keepLines2);
      styleParagraphProperties4.Append(spacingBetweenLines5);
      styleParagraphProperties4.Append(outlineLevel2);

      StyleRunProperties styleRunProperties5 = new StyleRunProperties();
      RunFonts runFonts8 = new RunFonts() { AsciiTheme = ThemeFontValues.MajorHighAnsi, HighAnsiTheme = ThemeFontValues.MajorHighAnsi, EastAsiaTheme = ThemeFontValues.MajorEastAsia, ComplexScriptTheme = ThemeFontValues.MajorBidi };
      Bold bold3 = new Bold();
      BoldComplexScript boldComplexScript3 = new BoldComplexScript();
      Color color5 = new Color() { Val = "365F91", ThemeColor = ThemeColorValues.Accent1, ThemeShade = "BF" };
      FontSize fontSize7 = new FontSize() { Val = "28" };
      FontSizeComplexScript fontSizeComplexScript7 = new FontSizeComplexScript() { Val = "28" };

      styleRunProperties5.Append(runFonts8);
      styleRunProperties5.Append(bold3);
      styleRunProperties5.Append(boldComplexScript3);
      styleRunProperties5.Append(color5);
      styleRunProperties5.Append(fontSize7);
      styleRunProperties5.Append(fontSizeComplexScript7);

      style11.Append(styleName11);
      style11.Append(basedOn6);
      style11.Append(nextParagraphStyle3);
      style11.Append(linkedStyle5);
      style11.Append(uIPriority9);
      style11.Append(primaryStyle6);
      style11.Append(rsid6);
      style11.Append(styleParagraphProperties4);
      style11.Append(styleRunProperties5);

      Style style12 = new Style() { Type = StyleValues.Character, StyleId = "DefaultParagraphFont", Default = true };
      StyleName styleName12 = new StyleName() { Val = "Default Paragraph Font" };
      UIPriority uIPriority10 = new UIPriority() { Val = 1 };
      SemiHidden semiHidden4 = new SemiHidden();
      UnhideWhenUsed unhideWhenUsed4 = new UnhideWhenUsed();

      style12.Append(styleName12);
      style12.Append(uIPriority10);
      style12.Append(semiHidden4);
      style12.Append(unhideWhenUsed4);

      Style style13 = new Style() { Type = StyleValues.Table, StyleId = "TableNormal", Default = true };
      StyleName styleName13 = new StyleName() { Val = "Normal Table" };
      UIPriority uIPriority11 = new UIPriority() { Val = 99 };
      SemiHidden semiHidden5 = new SemiHidden();
      UnhideWhenUsed unhideWhenUsed5 = new UnhideWhenUsed();

      StyleTableProperties styleTableProperties2 = new StyleTableProperties();
      TableIndentation tableIndentation2 = new TableIndentation() { Width = 0, Type = TableWidthUnitValues.Dxa };

      TableCellMarginDefault tableCellMarginDefault2 = new TableCellMarginDefault();
      TopMargin topMargin2 = new TopMargin() { Width = "0", Type = TableWidthUnitValues.Dxa };
      TableCellLeftMargin tableCellLeftMargin2 = new TableCellLeftMargin() { Width = 108, Type = TableWidthValues.Dxa };
      BottomMargin bottomMargin2 = new BottomMargin() { Width = "0", Type = TableWidthUnitValues.Dxa };
      TableCellRightMargin tableCellRightMargin2 = new TableCellRightMargin() { Width = 108, Type = TableWidthValues.Dxa };

      tableCellMarginDefault2.Append(topMargin2);
      tableCellMarginDefault2.Append(tableCellLeftMargin2);
      tableCellMarginDefault2.Append(bottomMargin2);
      tableCellMarginDefault2.Append(tableCellRightMargin2);

      styleTableProperties2.Append(tableIndentation2);
      styleTableProperties2.Append(tableCellMarginDefault2);

      style13.Append(styleName13);
      style13.Append(uIPriority11);
      style13.Append(semiHidden5);
      style13.Append(unhideWhenUsed5);
      style13.Append(styleTableProperties2);

      Style style14 = new Style() { Type = StyleValues.Numbering, StyleId = "NoList", Default = true };
      StyleName styleName14 = new StyleName() { Val = "No List" };
      UIPriority uIPriority12 = new UIPriority() { Val = 99 };
      SemiHidden semiHidden6 = new SemiHidden();
      UnhideWhenUsed unhideWhenUsed6 = new UnhideWhenUsed();

      style14.Append(styleName14);
      style14.Append(uIPriority12);
      style14.Append(semiHidden6);
      style14.Append(unhideWhenUsed6);

      Style style15 = new Style() { Type = StyleValues.Paragraph, StyleId = "Title" };
      StyleName styleName15 = new StyleName() { Val = "Title" };
      BasedOn basedOn7 = new BasedOn() { Val = "Normal" };
      NextParagraphStyle nextParagraphStyle4 = new NextParagraphStyle() { Val = "Normal" };
      LinkedStyle linkedStyle6 = new LinkedStyle() { Val = "TitleChar" };
      UIPriority uIPriority13 = new UIPriority() { Val = 10 };
      PrimaryStyle primaryStyle7 = new PrimaryStyle();
      Rsid rsid7 = new Rsid() { Val = "00146275" };

      StyleParagraphProperties styleParagraphProperties5 = new StyleParagraphProperties();

      ParagraphBorders paragraphBorders2 = new ParagraphBorders();
      BottomBorder bottomBorder2 = new BottomBorder() { Val = BorderValues.Single, Color = "4F81BD", ThemeColor = ThemeColorValues.Accent1, Size = (UInt32Value)8U, Space = (UInt32Value)4U };

      paragraphBorders2.Append(bottomBorder2);
      SpacingBetweenLines spacingBetweenLines6 = new SpacingBetweenLines() { After = "300", Line = "240", LineRule = LineSpacingRuleValues.Auto };
      ContextualSpacing contextualSpacing3 = new ContextualSpacing();

      styleParagraphProperties5.Append(paragraphBorders2);
      styleParagraphProperties5.Append(spacingBetweenLines6);
      styleParagraphProperties5.Append(contextualSpacing3);

      StyleRunProperties styleRunProperties6 = new StyleRunProperties();
      RunFonts runFonts9 = new RunFonts() { AsciiTheme = ThemeFontValues.MajorHighAnsi, HighAnsiTheme = ThemeFontValues.MajorHighAnsi, EastAsiaTheme = ThemeFontValues.MajorEastAsia, ComplexScriptTheme = ThemeFontValues.MajorBidi };
      Color color6 = new Color() { Val = "17365D", ThemeColor = ThemeColorValues.Text2, ThemeShade = "BF" };
      Spacing spacing3 = new Spacing() { Val = 5 };
      Kern kern3 = new Kern() { Val = (UInt32Value)28U };
      FontSize fontSize8 = new FontSize() { Val = "52" };
      FontSizeComplexScript fontSizeComplexScript8 = new FontSizeComplexScript() { Val = "52" };

      styleRunProperties6.Append(runFonts9);
      styleRunProperties6.Append(color6);
      styleRunProperties6.Append(spacing3);
      styleRunProperties6.Append(kern3);
      styleRunProperties6.Append(fontSize8);
      styleRunProperties6.Append(fontSizeComplexScript8);

      style15.Append(styleName15);
      style15.Append(basedOn7);
      style15.Append(nextParagraphStyle4);
      style15.Append(linkedStyle6);
      style15.Append(uIPriority13);
      style15.Append(primaryStyle7);
      style15.Append(rsid7);
      style15.Append(styleParagraphProperties5);
      style15.Append(styleRunProperties6);

      Style style16 = new Style() { Type = StyleValues.Character, StyleId = "TitleChar", CustomStyle = true };
      StyleName styleName16 = new StyleName() { Val = "Title Char" };
      BasedOn basedOn8 = new BasedOn() { Val = "DefaultParagraphFont" };
      LinkedStyle linkedStyle7 = new LinkedStyle() { Val = "Title" };
      UIPriority uIPriority14 = new UIPriority() { Val = 10 };
      Rsid rsid8 = new Rsid() { Val = "00146275" };

      StyleRunProperties styleRunProperties7 = new StyleRunProperties();
      RunFonts runFonts10 = new RunFonts() { AsciiTheme = ThemeFontValues.MajorHighAnsi, HighAnsiTheme = ThemeFontValues.MajorHighAnsi, EastAsiaTheme = ThemeFontValues.MajorEastAsia, ComplexScriptTheme = ThemeFontValues.MajorBidi };
      Color color7 = new Color() { Val = "17365D", ThemeColor = ThemeColorValues.Text2, ThemeShade = "BF" };
      Spacing spacing4 = new Spacing() { Val = 5 };
      Kern kern4 = new Kern() { Val = (UInt32Value)28U };
      FontSize fontSize9 = new FontSize() { Val = "52" };
      FontSizeComplexScript fontSizeComplexScript9 = new FontSizeComplexScript() { Val = "52" };

      styleRunProperties7.Append(runFonts10);
      styleRunProperties7.Append(color7);
      styleRunProperties7.Append(spacing4);
      styleRunProperties7.Append(kern4);
      styleRunProperties7.Append(fontSize9);
      styleRunProperties7.Append(fontSizeComplexScript9);

      style16.Append(styleName16);
      style16.Append(basedOn8);
      style16.Append(linkedStyle7);
      style16.Append(uIPriority14);
      style16.Append(rsid8);
      style16.Append(styleRunProperties7);

      Style style17 = new Style() { Type = StyleValues.Character, StyleId = "Heading1Char", CustomStyle = true };
      StyleName styleName17 = new StyleName() { Val = "Heading 1 Char" };
      BasedOn basedOn9 = new BasedOn() { Val = "DefaultParagraphFont" };
      LinkedStyle linkedStyle8 = new LinkedStyle() { Val = "Heading1" };
      UIPriority uIPriority15 = new UIPriority() { Val = 9 };
      Rsid rsid9 = new Rsid() { Val = "00146275" };

      StyleRunProperties styleRunProperties8 = new StyleRunProperties();
      RunFonts runFonts11 = new RunFonts() { AsciiTheme = ThemeFontValues.MajorHighAnsi, HighAnsiTheme = ThemeFontValues.MajorHighAnsi, EastAsiaTheme = ThemeFontValues.MajorEastAsia, ComplexScriptTheme = ThemeFontValues.MajorBidi };
      Bold bold4 = new Bold();
      BoldComplexScript boldComplexScript4 = new BoldComplexScript();
      Color color8 = new Color() { Val = "365F91", ThemeColor = ThemeColorValues.Accent1, ThemeShade = "BF" };
      FontSize fontSize10 = new FontSize() { Val = "28" };
      FontSizeComplexScript fontSizeComplexScript10 = new FontSizeComplexScript() { Val = "28" };

      styleRunProperties8.Append(runFonts11);
      styleRunProperties8.Append(bold4);
      styleRunProperties8.Append(boldComplexScript4);
      styleRunProperties8.Append(color8);
      styleRunProperties8.Append(fontSize10);
      styleRunProperties8.Append(fontSizeComplexScript10);

      style17.Append(styleName17);
      style17.Append(basedOn9);
      style17.Append(linkedStyle8);
      style17.Append(uIPriority15);
      style17.Append(rsid9);
      style17.Append(styleRunProperties8);

      Style style18 = new Style() { Type = StyleValues.Paragraph, StyleId = "ListParagraph" };
      StyleName styleName18 = new StyleName() { Val = "List Paragraph" };
      BasedOn basedOn10 = new BasedOn() { Val = "Normal" };
      UIPriority uIPriority16 = new UIPriority() { Val = 34 };
      PrimaryStyle primaryStyle8 = new PrimaryStyle();
      Rsid rsid10 = new Rsid() { Val = "00146275" };

      StyleParagraphProperties styleParagraphProperties6 = new StyleParagraphProperties();

      NumberingProperties numberingProperties2 = new NumberingProperties();
      NumberingId numberingId2 = new NumberingId() { Val = 3 };

      numberingProperties2.Append(numberingId2);
      ContextualSpacing contextualSpacing4 = new ContextualSpacing();

      styleParagraphProperties6.Append(numberingProperties2);
      styleParagraphProperties6.Append(contextualSpacing4);

      style18.Append(styleName18);
      style18.Append(basedOn10);
      style18.Append(uIPriority16);
      style18.Append(primaryStyle8);
      style18.Append(rsid10);
      style18.Append(styleParagraphProperties6);

      styles2.Append(docDefaults2);
      styles2.Append(latentStyles2);
      styles2.Append(style10);
      styles2.Append(style11);
      styles2.Append(style12);
      styles2.Append(style13);
      styles2.Append(style14);
      styles2.Append(style15);
      styles2.Append(style16);
      styles2.Append(style17);
      styles2.Append(style18);

      styleDefinitionsPart1.Styles = styles2;
    }

    // Generates content of numberingDefinitionsPart1.
    private void GenerateNumberingDefinitionsPart1Content(NumberingDefinitionsPart numberingDefinitionsPart1)
    {
      Numbering numbering1 = new Numbering() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14 wp14" } };
      numbering1.AddNamespaceDeclaration("wpc", "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas");
      numbering1.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
      numbering1.AddNamespaceDeclaration("o", "urn:schemas-microsoft-com:office:office");
      numbering1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
      numbering1.AddNamespaceDeclaration("m", "http://schemas.openxmlformats.org/officeDocument/2006/math");
      numbering1.AddNamespaceDeclaration("v", "urn:schemas-microsoft-com:vml");
      numbering1.AddNamespaceDeclaration("wp14", "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing");
      numbering1.AddNamespaceDeclaration("wp", "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing");
      numbering1.AddNamespaceDeclaration("w10", "urn:schemas-microsoft-com:office:word");
      numbering1.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
      numbering1.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");
      numbering1.AddNamespaceDeclaration("wpg", "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup");
      numbering1.AddNamespaceDeclaration("wpi", "http://schemas.microsoft.com/office/word/2010/wordprocessingInk");
      numbering1.AddNamespaceDeclaration("wne", "http://schemas.microsoft.com/office/word/2006/wordml");
      numbering1.AddNamespaceDeclaration("wps", "http://schemas.microsoft.com/office/word/2010/wordprocessingShape");

      AbstractNum abstractNum1 = new AbstractNum() { AbstractNumberId = 0 };
      Nsid nsid1 = new Nsid() { Val = "340B3AFC" };
      MultiLevelType multiLevelType1 = new MultiLevelType() { Val = MultiLevelValues.HybridMultilevel };
      TemplateCode templateCode1 = new TemplateCode() { Val = "0C3EE340" };

      Level level1 = new Level() { LevelIndex = 0, TemplateCode = "C9EE3918" };
      StartNumberingValue startNumberingValue1 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat1 = new NumberingFormat() { Val = NumberFormatValues.Decimal };
      ParagraphStyleIdInLevel paragraphStyleIdInLevel1 = new ParagraphStyleIdInLevel() { Val = "ListParagraph" };
      LevelText levelText1 = new LevelText() { Val = "%1." };
      LevelJustification levelJustification1 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties1 = new PreviousParagraphProperties();
      Indentation indentation1 = new Indentation() { Left = "360", Hanging = "360" };

      previousParagraphProperties1.Append(indentation1);

      level1.Append(startNumberingValue1);
      level1.Append(numberingFormat1);
      level1.Append(paragraphStyleIdInLevel1);
      level1.Append(levelText1);
      level1.Append(levelJustification1);
      level1.Append(previousParagraphProperties1);

      Level level2 = new Level() { LevelIndex = 1, TemplateCode = "0C090019", Tentative = true };
      StartNumberingValue startNumberingValue2 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat2 = new NumberingFormat() { Val = NumberFormatValues.LowerLetter };
      LevelText levelText2 = new LevelText() { Val = "%2." };
      LevelJustification levelJustification2 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties2 = new PreviousParagraphProperties();
      Indentation indentation2 = new Indentation() { Left = "1080", Hanging = "360" };

      previousParagraphProperties2.Append(indentation2);

      level2.Append(startNumberingValue2);
      level2.Append(numberingFormat2);
      level2.Append(levelText2);
      level2.Append(levelJustification2);
      level2.Append(previousParagraphProperties2);

      Level level3 = new Level() { LevelIndex = 2, TemplateCode = "0C09001B", Tentative = true };
      StartNumberingValue startNumberingValue3 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat3 = new NumberingFormat() { Val = NumberFormatValues.LowerRoman };
      LevelText levelText3 = new LevelText() { Val = "%3." };
      LevelJustification levelJustification3 = new LevelJustification() { Val = LevelJustificationValues.Right };

      PreviousParagraphProperties previousParagraphProperties3 = new PreviousParagraphProperties();
      Indentation indentation3 = new Indentation() { Left = "1800", Hanging = "180" };

      previousParagraphProperties3.Append(indentation3);

      level3.Append(startNumberingValue3);
      level3.Append(numberingFormat3);
      level3.Append(levelText3);
      level3.Append(levelJustification3);
      level3.Append(previousParagraphProperties3);

      Level level4 = new Level() { LevelIndex = 3, TemplateCode = "0C09000F", Tentative = true };
      StartNumberingValue startNumberingValue4 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat4 = new NumberingFormat() { Val = NumberFormatValues.Decimal };
      LevelText levelText4 = new LevelText() { Val = "%4." };
      LevelJustification levelJustification4 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties4 = new PreviousParagraphProperties();
      Indentation indentation4 = new Indentation() { Left = "2520", Hanging = "360" };

      previousParagraphProperties4.Append(indentation4);

      level4.Append(startNumberingValue4);
      level4.Append(numberingFormat4);
      level4.Append(levelText4);
      level4.Append(levelJustification4);
      level4.Append(previousParagraphProperties4);

      Level level5 = new Level() { LevelIndex = 4, TemplateCode = "0C090019", Tentative = true };
      StartNumberingValue startNumberingValue5 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat5 = new NumberingFormat() { Val = NumberFormatValues.LowerLetter };
      LevelText levelText5 = new LevelText() { Val = "%5." };
      LevelJustification levelJustification5 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties5 = new PreviousParagraphProperties();
      Indentation indentation5 = new Indentation() { Left = "3240", Hanging = "360" };

      previousParagraphProperties5.Append(indentation5);

      level5.Append(startNumberingValue5);
      level5.Append(numberingFormat5);
      level5.Append(levelText5);
      level5.Append(levelJustification5);
      level5.Append(previousParagraphProperties5);

      Level level6 = new Level() { LevelIndex = 5, TemplateCode = "0C09001B", Tentative = true };
      StartNumberingValue startNumberingValue6 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat6 = new NumberingFormat() { Val = NumberFormatValues.LowerRoman };
      LevelText levelText6 = new LevelText() { Val = "%6." };
      LevelJustification levelJustification6 = new LevelJustification() { Val = LevelJustificationValues.Right };

      PreviousParagraphProperties previousParagraphProperties6 = new PreviousParagraphProperties();
      Indentation indentation6 = new Indentation() { Left = "3960", Hanging = "180" };

      previousParagraphProperties6.Append(indentation6);

      level6.Append(startNumberingValue6);
      level6.Append(numberingFormat6);
      level6.Append(levelText6);
      level6.Append(levelJustification6);
      level6.Append(previousParagraphProperties6);

      Level level7 = new Level() { LevelIndex = 6, TemplateCode = "0C09000F", Tentative = true };
      StartNumberingValue startNumberingValue7 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat7 = new NumberingFormat() { Val = NumberFormatValues.Decimal };
      LevelText levelText7 = new LevelText() { Val = "%7." };
      LevelJustification levelJustification7 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties7 = new PreviousParagraphProperties();
      Indentation indentation7 = new Indentation() { Left = "4680", Hanging = "360" };

      previousParagraphProperties7.Append(indentation7);

      level7.Append(startNumberingValue7);
      level7.Append(numberingFormat7);
      level7.Append(levelText7);
      level7.Append(levelJustification7);
      level7.Append(previousParagraphProperties7);

      Level level8 = new Level() { LevelIndex = 7, TemplateCode = "0C090019", Tentative = true };
      StartNumberingValue startNumberingValue8 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat8 = new NumberingFormat() { Val = NumberFormatValues.LowerLetter };
      LevelText levelText8 = new LevelText() { Val = "%8." };
      LevelJustification levelJustification8 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties8 = new PreviousParagraphProperties();
      Indentation indentation8 = new Indentation() { Left = "5400", Hanging = "360" };

      previousParagraphProperties8.Append(indentation8);

      level8.Append(startNumberingValue8);
      level8.Append(numberingFormat8);
      level8.Append(levelText8);
      level8.Append(levelJustification8);
      level8.Append(previousParagraphProperties8);

      Level level9 = new Level() { LevelIndex = 8, TemplateCode = "0C09001B", Tentative = true };
      StartNumberingValue startNumberingValue9 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat9 = new NumberingFormat() { Val = NumberFormatValues.LowerRoman };
      LevelText levelText9 = new LevelText() { Val = "%9." };
      LevelJustification levelJustification9 = new LevelJustification() { Val = LevelJustificationValues.Right };

      PreviousParagraphProperties previousParagraphProperties9 = new PreviousParagraphProperties();
      Indentation indentation9 = new Indentation() { Left = "6120", Hanging = "180" };

      previousParagraphProperties9.Append(indentation9);

      level9.Append(startNumberingValue9);
      level9.Append(numberingFormat9);
      level9.Append(levelText9);
      level9.Append(levelJustification9);
      level9.Append(previousParagraphProperties9);

      abstractNum1.Append(nsid1);
      abstractNum1.Append(multiLevelType1);
      abstractNum1.Append(templateCode1);
      abstractNum1.Append(level1);
      abstractNum1.Append(level2);
      abstractNum1.Append(level3);
      abstractNum1.Append(level4);
      abstractNum1.Append(level5);
      abstractNum1.Append(level6);
      abstractNum1.Append(level7);
      abstractNum1.Append(level8);
      abstractNum1.Append(level9);

      AbstractNum abstractNum2 = new AbstractNum() { AbstractNumberId = 1 };
      Nsid nsid2 = new Nsid() { Val = "5A0A05E7" };
      MultiLevelType multiLevelType2 = new MultiLevelType() { Val = MultiLevelValues.HybridMultilevel };
      TemplateCode templateCode2 = new TemplateCode() { Val = "3D180F6C" };

      Level level10 = new Level() { LevelIndex = 0, TemplateCode = "E4E02950" };
      StartNumberingValue startNumberingValue10 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat10 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText10 = new LevelText() { Val = "•" };
      LevelJustification levelJustification10 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties10 = new PreviousParagraphProperties();

      Tabs tabs1 = new Tabs();
      TabStop tabStop1 = new TabStop() { Val = TabStopValues.Number, Position = 720 };

      tabs1.Append(tabStop1);
      Indentation indentation10 = new Indentation() { Left = "720", Hanging = "360" };

      previousParagraphProperties10.Append(tabs1);
      previousParagraphProperties10.Append(indentation10);

      NumberingSymbolRunProperties numberingSymbolRunProperties1 = new NumberingSymbolRunProperties();
      RunFonts runFonts12 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties1.Append(runFonts12);

      level10.Append(startNumberingValue10);
      level10.Append(numberingFormat10);
      level10.Append(levelText10);
      level10.Append(levelJustification10);
      level10.Append(previousParagraphProperties10);
      level10.Append(numberingSymbolRunProperties1);

      Level level11 = new Level() { LevelIndex = 1, TemplateCode = "4440B53C", Tentative = true };
      StartNumberingValue startNumberingValue11 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat11 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText11 = new LevelText() { Val = "•" };
      LevelJustification levelJustification11 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties11 = new PreviousParagraphProperties();

      Tabs tabs2 = new Tabs();
      TabStop tabStop2 = new TabStop() { Val = TabStopValues.Number, Position = 1440 };

      tabs2.Append(tabStop2);
      Indentation indentation11 = new Indentation() { Left = "1440", Hanging = "360" };

      previousParagraphProperties11.Append(tabs2);
      previousParagraphProperties11.Append(indentation11);

      NumberingSymbolRunProperties numberingSymbolRunProperties2 = new NumberingSymbolRunProperties();
      RunFonts runFonts13 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties2.Append(runFonts13);

      level11.Append(startNumberingValue11);
      level11.Append(numberingFormat11);
      level11.Append(levelText11);
      level11.Append(levelJustification11);
      level11.Append(previousParagraphProperties11);
      level11.Append(numberingSymbolRunProperties2);

      Level level12 = new Level() { LevelIndex = 2, TemplateCode = "73CA92EA", Tentative = true };
      StartNumberingValue startNumberingValue12 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat12 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText12 = new LevelText() { Val = "•" };
      LevelJustification levelJustification12 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties12 = new PreviousParagraphProperties();

      Tabs tabs3 = new Tabs();
      TabStop tabStop3 = new TabStop() { Val = TabStopValues.Number, Position = 2160 };

      tabs3.Append(tabStop3);
      Indentation indentation12 = new Indentation() { Left = "2160", Hanging = "360" };

      previousParagraphProperties12.Append(tabs3);
      previousParagraphProperties12.Append(indentation12);

      NumberingSymbolRunProperties numberingSymbolRunProperties3 = new NumberingSymbolRunProperties();
      RunFonts runFonts14 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties3.Append(runFonts14);

      level12.Append(startNumberingValue12);
      level12.Append(numberingFormat12);
      level12.Append(levelText12);
      level12.Append(levelJustification12);
      level12.Append(previousParagraphProperties12);
      level12.Append(numberingSymbolRunProperties3);

      Level level13 = new Level() { LevelIndex = 3, TemplateCode = "99085DC2", Tentative = true };
      StartNumberingValue startNumberingValue13 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat13 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText13 = new LevelText() { Val = "•" };
      LevelJustification levelJustification13 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties13 = new PreviousParagraphProperties();

      Tabs tabs4 = new Tabs();
      TabStop tabStop4 = new TabStop() { Val = TabStopValues.Number, Position = 2880 };

      tabs4.Append(tabStop4);
      Indentation indentation13 = new Indentation() { Left = "2880", Hanging = "360" };

      previousParagraphProperties13.Append(tabs4);
      previousParagraphProperties13.Append(indentation13);

      NumberingSymbolRunProperties numberingSymbolRunProperties4 = new NumberingSymbolRunProperties();
      RunFonts runFonts15 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties4.Append(runFonts15);

      level13.Append(startNumberingValue13);
      level13.Append(numberingFormat13);
      level13.Append(levelText13);
      level13.Append(levelJustification13);
      level13.Append(previousParagraphProperties13);
      level13.Append(numberingSymbolRunProperties4);

      Level level14 = new Level() { LevelIndex = 4, TemplateCode = "33CA5C36", Tentative = true };
      StartNumberingValue startNumberingValue14 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat14 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText14 = new LevelText() { Val = "•" };
      LevelJustification levelJustification14 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties14 = new PreviousParagraphProperties();

      Tabs tabs5 = new Tabs();
      TabStop tabStop5 = new TabStop() { Val = TabStopValues.Number, Position = 3600 };

      tabs5.Append(tabStop5);
      Indentation indentation14 = new Indentation() { Left = "3600", Hanging = "360" };

      previousParagraphProperties14.Append(tabs5);
      previousParagraphProperties14.Append(indentation14);

      NumberingSymbolRunProperties numberingSymbolRunProperties5 = new NumberingSymbolRunProperties();
      RunFonts runFonts16 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties5.Append(runFonts16);

      level14.Append(startNumberingValue14);
      level14.Append(numberingFormat14);
      level14.Append(levelText14);
      level14.Append(levelJustification14);
      level14.Append(previousParagraphProperties14);
      level14.Append(numberingSymbolRunProperties5);

      Level level15 = new Level() { LevelIndex = 5, TemplateCode = "F04059C8", Tentative = true };
      StartNumberingValue startNumberingValue15 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat15 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText15 = new LevelText() { Val = "•" };
      LevelJustification levelJustification15 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties15 = new PreviousParagraphProperties();

      Tabs tabs6 = new Tabs();
      TabStop tabStop6 = new TabStop() { Val = TabStopValues.Number, Position = 4320 };

      tabs6.Append(tabStop6);
      Indentation indentation15 = new Indentation() { Left = "4320", Hanging = "360" };

      previousParagraphProperties15.Append(tabs6);
      previousParagraphProperties15.Append(indentation15);

      NumberingSymbolRunProperties numberingSymbolRunProperties6 = new NumberingSymbolRunProperties();
      RunFonts runFonts17 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties6.Append(runFonts17);

      level15.Append(startNumberingValue15);
      level15.Append(numberingFormat15);
      level15.Append(levelText15);
      level15.Append(levelJustification15);
      level15.Append(previousParagraphProperties15);
      level15.Append(numberingSymbolRunProperties6);

      Level level16 = new Level() { LevelIndex = 6, TemplateCode = "D716F274", Tentative = true };
      StartNumberingValue startNumberingValue16 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat16 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText16 = new LevelText() { Val = "•" };
      LevelJustification levelJustification16 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties16 = new PreviousParagraphProperties();

      Tabs tabs7 = new Tabs();
      TabStop tabStop7 = new TabStop() { Val = TabStopValues.Number, Position = 5040 };

      tabs7.Append(tabStop7);
      Indentation indentation16 = new Indentation() { Left = "5040", Hanging = "360" };

      previousParagraphProperties16.Append(tabs7);
      previousParagraphProperties16.Append(indentation16);

      NumberingSymbolRunProperties numberingSymbolRunProperties7 = new NumberingSymbolRunProperties();
      RunFonts runFonts18 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties7.Append(runFonts18);

      level16.Append(startNumberingValue16);
      level16.Append(numberingFormat16);
      level16.Append(levelText16);
      level16.Append(levelJustification16);
      level16.Append(previousParagraphProperties16);
      level16.Append(numberingSymbolRunProperties7);

      Level level17 = new Level() { LevelIndex = 7, TemplateCode = "CD280050", Tentative = true };
      StartNumberingValue startNumberingValue17 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat17 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText17 = new LevelText() { Val = "•" };
      LevelJustification levelJustification17 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties17 = new PreviousParagraphProperties();

      Tabs tabs8 = new Tabs();
      TabStop tabStop8 = new TabStop() { Val = TabStopValues.Number, Position = 5760 };

      tabs8.Append(tabStop8);
      Indentation indentation17 = new Indentation() { Left = "5760", Hanging = "360" };

      previousParagraphProperties17.Append(tabs8);
      previousParagraphProperties17.Append(indentation17);

      NumberingSymbolRunProperties numberingSymbolRunProperties8 = new NumberingSymbolRunProperties();
      RunFonts runFonts19 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties8.Append(runFonts19);

      level17.Append(startNumberingValue17);
      level17.Append(numberingFormat17);
      level17.Append(levelText17);
      level17.Append(levelJustification17);
      level17.Append(previousParagraphProperties17);
      level17.Append(numberingSymbolRunProperties8);

      Level level18 = new Level() { LevelIndex = 8, TemplateCode = "67A49292", Tentative = true };
      StartNumberingValue startNumberingValue18 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat18 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText18 = new LevelText() { Val = "•" };
      LevelJustification levelJustification18 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties18 = new PreviousParagraphProperties();

      Tabs tabs9 = new Tabs();
      TabStop tabStop9 = new TabStop() { Val = TabStopValues.Number, Position = 6480 };

      tabs9.Append(tabStop9);
      Indentation indentation18 = new Indentation() { Left = "6480", Hanging = "360" };

      previousParagraphProperties18.Append(tabs9);
      previousParagraphProperties18.Append(indentation18);

      NumberingSymbolRunProperties numberingSymbolRunProperties9 = new NumberingSymbolRunProperties();
      RunFonts runFonts20 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Arial", HighAnsi = "Arial" };

      numberingSymbolRunProperties9.Append(runFonts20);

      level18.Append(startNumberingValue18);
      level18.Append(numberingFormat18);
      level18.Append(levelText18);
      level18.Append(levelJustification18);
      level18.Append(previousParagraphProperties18);
      level18.Append(numberingSymbolRunProperties9);

      abstractNum2.Append(nsid2);
      abstractNum2.Append(multiLevelType2);
      abstractNum2.Append(templateCode2);
      abstractNum2.Append(level10);
      abstractNum2.Append(level11);
      abstractNum2.Append(level12);
      abstractNum2.Append(level13);
      abstractNum2.Append(level14);
      abstractNum2.Append(level15);
      abstractNum2.Append(level16);
      abstractNum2.Append(level17);
      abstractNum2.Append(level18);

      AbstractNum abstractNum3 = new AbstractNum() { AbstractNumberId = 2 };
      Nsid nsid3 = new Nsid() { Val = "5A6473D7" };
      MultiLevelType multiLevelType3 = new MultiLevelType() { Val = MultiLevelValues.HybridMultilevel };
      TemplateCode templateCode3 = new TemplateCode() { Val = "AD9814E0" };

      Level level19 = new Level() { LevelIndex = 0, TemplateCode = "0C09000F" };
      StartNumberingValue startNumberingValue19 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat19 = new NumberingFormat() { Val = NumberFormatValues.Decimal };
      LevelText levelText19 = new LevelText() { Val = "%1." };
      LevelJustification levelJustification19 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties19 = new PreviousParagraphProperties();
      Indentation indentation19 = new Indentation() { Left = "720", Hanging = "360" };

      previousParagraphProperties19.Append(indentation19);

      level19.Append(startNumberingValue19);
      level19.Append(numberingFormat19);
      level19.Append(levelText19);
      level19.Append(levelJustification19);
      level19.Append(previousParagraphProperties19);

      Level level20 = new Level() { LevelIndex = 1, TemplateCode = "0C090019", Tentative = true };
      StartNumberingValue startNumberingValue20 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat20 = new NumberingFormat() { Val = NumberFormatValues.LowerLetter };
      LevelText levelText20 = new LevelText() { Val = "%2." };
      LevelJustification levelJustification20 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties20 = new PreviousParagraphProperties();
      Indentation indentation20 = new Indentation() { Left = "1440", Hanging = "360" };

      previousParagraphProperties20.Append(indentation20);

      level20.Append(startNumberingValue20);
      level20.Append(numberingFormat20);
      level20.Append(levelText20);
      level20.Append(levelJustification20);
      level20.Append(previousParagraphProperties20);

      Level level21 = new Level() { LevelIndex = 2, TemplateCode = "0C09001B", Tentative = true };
      StartNumberingValue startNumberingValue21 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat21 = new NumberingFormat() { Val = NumberFormatValues.LowerRoman };
      LevelText levelText21 = new LevelText() { Val = "%3." };
      LevelJustification levelJustification21 = new LevelJustification() { Val = LevelJustificationValues.Right };

      PreviousParagraphProperties previousParagraphProperties21 = new PreviousParagraphProperties();
      Indentation indentation21 = new Indentation() { Left = "2160", Hanging = "180" };

      previousParagraphProperties21.Append(indentation21);

      level21.Append(startNumberingValue21);
      level21.Append(numberingFormat21);
      level21.Append(levelText21);
      level21.Append(levelJustification21);
      level21.Append(previousParagraphProperties21);

      Level level22 = new Level() { LevelIndex = 3, TemplateCode = "0C09000F", Tentative = true };
      StartNumberingValue startNumberingValue22 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat22 = new NumberingFormat() { Val = NumberFormatValues.Decimal };
      LevelText levelText22 = new LevelText() { Val = "%4." };
      LevelJustification levelJustification22 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties22 = new PreviousParagraphProperties();
      Indentation indentation22 = new Indentation() { Left = "2880", Hanging = "360" };

      previousParagraphProperties22.Append(indentation22);

      level22.Append(startNumberingValue22);
      level22.Append(numberingFormat22);
      level22.Append(levelText22);
      level22.Append(levelJustification22);
      level22.Append(previousParagraphProperties22);

      Level level23 = new Level() { LevelIndex = 4, TemplateCode = "0C090019", Tentative = true };
      StartNumberingValue startNumberingValue23 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat23 = new NumberingFormat() { Val = NumberFormatValues.LowerLetter };
      LevelText levelText23 = new LevelText() { Val = "%5." };
      LevelJustification levelJustification23 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties23 = new PreviousParagraphProperties();
      Indentation indentation23 = new Indentation() { Left = "3600", Hanging = "360" };

      previousParagraphProperties23.Append(indentation23);

      level23.Append(startNumberingValue23);
      level23.Append(numberingFormat23);
      level23.Append(levelText23);
      level23.Append(levelJustification23);
      level23.Append(previousParagraphProperties23);

      Level level24 = new Level() { LevelIndex = 5, TemplateCode = "0C09001B", Tentative = true };
      StartNumberingValue startNumberingValue24 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat24 = new NumberingFormat() { Val = NumberFormatValues.LowerRoman };
      LevelText levelText24 = new LevelText() { Val = "%6." };
      LevelJustification levelJustification24 = new LevelJustification() { Val = LevelJustificationValues.Right };

      PreviousParagraphProperties previousParagraphProperties24 = new PreviousParagraphProperties();
      Indentation indentation24 = new Indentation() { Left = "4320", Hanging = "180" };

      previousParagraphProperties24.Append(indentation24);

      level24.Append(startNumberingValue24);
      level24.Append(numberingFormat24);
      level24.Append(levelText24);
      level24.Append(levelJustification24);
      level24.Append(previousParagraphProperties24);

      Level level25 = new Level() { LevelIndex = 6, TemplateCode = "0C09000F", Tentative = true };
      StartNumberingValue startNumberingValue25 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat25 = new NumberingFormat() { Val = NumberFormatValues.Decimal };
      LevelText levelText25 = new LevelText() { Val = "%7." };
      LevelJustification levelJustification25 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties25 = new PreviousParagraphProperties();
      Indentation indentation25 = new Indentation() { Left = "5040", Hanging = "360" };

      previousParagraphProperties25.Append(indentation25);

      level25.Append(startNumberingValue25);
      level25.Append(numberingFormat25);
      level25.Append(levelText25);
      level25.Append(levelJustification25);
      level25.Append(previousParagraphProperties25);

      Level level26 = new Level() { LevelIndex = 7, TemplateCode = "0C090019", Tentative = true };
      StartNumberingValue startNumberingValue26 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat26 = new NumberingFormat() { Val = NumberFormatValues.LowerLetter };
      LevelText levelText26 = new LevelText() { Val = "%8." };
      LevelJustification levelJustification26 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties26 = new PreviousParagraphProperties();
      Indentation indentation26 = new Indentation() { Left = "5760", Hanging = "360" };

      previousParagraphProperties26.Append(indentation26);

      level26.Append(startNumberingValue26);
      level26.Append(numberingFormat26);
      level26.Append(levelText26);
      level26.Append(levelJustification26);
      level26.Append(previousParagraphProperties26);

      Level level27 = new Level() { LevelIndex = 8, TemplateCode = "0C09001B", Tentative = true };
      StartNumberingValue startNumberingValue27 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat27 = new NumberingFormat() { Val = NumberFormatValues.LowerRoman };
      LevelText levelText27 = new LevelText() { Val = "%9." };
      LevelJustification levelJustification27 = new LevelJustification() { Val = LevelJustificationValues.Right };

      PreviousParagraphProperties previousParagraphProperties27 = new PreviousParagraphProperties();
      Indentation indentation27 = new Indentation() { Left = "6480", Hanging = "180" };

      previousParagraphProperties27.Append(indentation27);

      level27.Append(startNumberingValue27);
      level27.Append(numberingFormat27);
      level27.Append(levelText27);
      level27.Append(levelJustification27);
      level27.Append(previousParagraphProperties27);

      abstractNum3.Append(nsid3);
      abstractNum3.Append(multiLevelType3);
      abstractNum3.Append(templateCode3);
      abstractNum3.Append(level19);
      abstractNum3.Append(level20);
      abstractNum3.Append(level21);
      abstractNum3.Append(level22);
      abstractNum3.Append(level23);
      abstractNum3.Append(level24);
      abstractNum3.Append(level25);
      abstractNum3.Append(level26);
      abstractNum3.Append(level27);

      AbstractNum abstractNum4 = new AbstractNum() { AbstractNumberId = 3 };
      Nsid nsid4 = new Nsid() { Val = "694A7A34" };
      MultiLevelType multiLevelType4 = new MultiLevelType() { Val = MultiLevelValues.HybridMultilevel };
      TemplateCode templateCode4 = new TemplateCode() { Val = "D2E4F78E" };

      Level level28 = new Level() { LevelIndex = 0, TemplateCode = "0C090001" };
      StartNumberingValue startNumberingValue28 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat28 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText28 = new LevelText() { Val = "·" };
      LevelJustification levelJustification28 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties28 = new PreviousParagraphProperties();
      Indentation indentation28 = new Indentation() { Left = "720", Hanging = "360" };

      previousParagraphProperties28.Append(indentation28);

      NumberingSymbolRunProperties numberingSymbolRunProperties10 = new NumberingSymbolRunProperties();
      RunFonts runFonts21 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Symbol", HighAnsi = "Symbol" };

      numberingSymbolRunProperties10.Append(runFonts21);

      level28.Append(startNumberingValue28);
      level28.Append(numberingFormat28);
      level28.Append(levelText28);
      level28.Append(levelJustification28);
      level28.Append(previousParagraphProperties28);
      level28.Append(numberingSymbolRunProperties10);

      Level level29 = new Level() { LevelIndex = 1, TemplateCode = "0C090003", Tentative = true };
      StartNumberingValue startNumberingValue29 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat29 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText29 = new LevelText() { Val = "o" };
      LevelJustification levelJustification29 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties29 = new PreviousParagraphProperties();
      Indentation indentation29 = new Indentation() { Left = "1440", Hanging = "360" };

      previousParagraphProperties29.Append(indentation29);

      NumberingSymbolRunProperties numberingSymbolRunProperties11 = new NumberingSymbolRunProperties();
      RunFonts runFonts22 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Courier New", HighAnsi = "Courier New", ComplexScript = "Courier New" };

      numberingSymbolRunProperties11.Append(runFonts22);

      level29.Append(startNumberingValue29);
      level29.Append(numberingFormat29);
      level29.Append(levelText29);
      level29.Append(levelJustification29);
      level29.Append(previousParagraphProperties29);
      level29.Append(numberingSymbolRunProperties11);

      Level level30 = new Level() { LevelIndex = 2, TemplateCode = "0C090005", Tentative = true };
      StartNumberingValue startNumberingValue30 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat30 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText30 = new LevelText() { Val = "§" };
      LevelJustification levelJustification30 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties30 = new PreviousParagraphProperties();
      Indentation indentation30 = new Indentation() { Left = "2160", Hanging = "360" };

      previousParagraphProperties30.Append(indentation30);

      NumberingSymbolRunProperties numberingSymbolRunProperties12 = new NumberingSymbolRunProperties();
      RunFonts runFonts23 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Wingdings", HighAnsi = "Wingdings" };

      numberingSymbolRunProperties12.Append(runFonts23);

      level30.Append(startNumberingValue30);
      level30.Append(numberingFormat30);
      level30.Append(levelText30);
      level30.Append(levelJustification30);
      level30.Append(previousParagraphProperties30);
      level30.Append(numberingSymbolRunProperties12);

      Level level31 = new Level() { LevelIndex = 3, TemplateCode = "0C090001", Tentative = true };
      StartNumberingValue startNumberingValue31 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat31 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText31 = new LevelText() { Val = "·" };
      LevelJustification levelJustification31 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties31 = new PreviousParagraphProperties();
      Indentation indentation31 = new Indentation() { Left = "2880", Hanging = "360" };

      previousParagraphProperties31.Append(indentation31);

      NumberingSymbolRunProperties numberingSymbolRunProperties13 = new NumberingSymbolRunProperties();
      RunFonts runFonts24 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Symbol", HighAnsi = "Symbol" };

      numberingSymbolRunProperties13.Append(runFonts24);

      level31.Append(startNumberingValue31);
      level31.Append(numberingFormat31);
      level31.Append(levelText31);
      level31.Append(levelJustification31);
      level31.Append(previousParagraphProperties31);
      level31.Append(numberingSymbolRunProperties13);

      Level level32 = new Level() { LevelIndex = 4, TemplateCode = "0C090003", Tentative = true };
      StartNumberingValue startNumberingValue32 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat32 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText32 = new LevelText() { Val = "o" };
      LevelJustification levelJustification32 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties32 = new PreviousParagraphProperties();
      Indentation indentation32 = new Indentation() { Left = "3600", Hanging = "360" };

      previousParagraphProperties32.Append(indentation32);

      NumberingSymbolRunProperties numberingSymbolRunProperties14 = new NumberingSymbolRunProperties();
      RunFonts runFonts25 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Courier New", HighAnsi = "Courier New", ComplexScript = "Courier New" };

      numberingSymbolRunProperties14.Append(runFonts25);

      level32.Append(startNumberingValue32);
      level32.Append(numberingFormat32);
      level32.Append(levelText32);
      level32.Append(levelJustification32);
      level32.Append(previousParagraphProperties32);
      level32.Append(numberingSymbolRunProperties14);

      Level level33 = new Level() { LevelIndex = 5, TemplateCode = "0C090005", Tentative = true };
      StartNumberingValue startNumberingValue33 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat33 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText33 = new LevelText() { Val = "§" };
      LevelJustification levelJustification33 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties33 = new PreviousParagraphProperties();
      Indentation indentation33 = new Indentation() { Left = "4320", Hanging = "360" };

      previousParagraphProperties33.Append(indentation33);

      NumberingSymbolRunProperties numberingSymbolRunProperties15 = new NumberingSymbolRunProperties();
      RunFonts runFonts26 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Wingdings", HighAnsi = "Wingdings" };

      numberingSymbolRunProperties15.Append(runFonts26);

      level33.Append(startNumberingValue33);
      level33.Append(numberingFormat33);
      level33.Append(levelText33);
      level33.Append(levelJustification33);
      level33.Append(previousParagraphProperties33);
      level33.Append(numberingSymbolRunProperties15);

      Level level34 = new Level() { LevelIndex = 6, TemplateCode = "0C090001", Tentative = true };
      StartNumberingValue startNumberingValue34 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat34 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText34 = new LevelText() { Val = "·" };
      LevelJustification levelJustification34 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties34 = new PreviousParagraphProperties();
      Indentation indentation34 = new Indentation() { Left = "5040", Hanging = "360" };

      previousParagraphProperties34.Append(indentation34);

      NumberingSymbolRunProperties numberingSymbolRunProperties16 = new NumberingSymbolRunProperties();
      RunFonts runFonts27 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Symbol", HighAnsi = "Symbol" };

      numberingSymbolRunProperties16.Append(runFonts27);

      level34.Append(startNumberingValue34);
      level34.Append(numberingFormat34);
      level34.Append(levelText34);
      level34.Append(levelJustification34);
      level34.Append(previousParagraphProperties34);
      level34.Append(numberingSymbolRunProperties16);

      Level level35 = new Level() { LevelIndex = 7, TemplateCode = "0C090003", Tentative = true };
      StartNumberingValue startNumberingValue35 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat35 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText35 = new LevelText() { Val = "o" };
      LevelJustification levelJustification35 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties35 = new PreviousParagraphProperties();
      Indentation indentation35 = new Indentation() { Left = "5760", Hanging = "360" };

      previousParagraphProperties35.Append(indentation35);

      NumberingSymbolRunProperties numberingSymbolRunProperties17 = new NumberingSymbolRunProperties();
      RunFonts runFonts28 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Courier New", HighAnsi = "Courier New", ComplexScript = "Courier New" };

      numberingSymbolRunProperties17.Append(runFonts28);

      level35.Append(startNumberingValue35);
      level35.Append(numberingFormat35);
      level35.Append(levelText35);
      level35.Append(levelJustification35);
      level35.Append(previousParagraphProperties35);
      level35.Append(numberingSymbolRunProperties17);

      Level level36 = new Level() { LevelIndex = 8, TemplateCode = "0C090005", Tentative = true };
      StartNumberingValue startNumberingValue36 = new StartNumberingValue() { Val = 1 };
      NumberingFormat numberingFormat36 = new NumberingFormat() { Val = NumberFormatValues.Bullet };
      LevelText levelText36 = new LevelText() { Val = "§" };
      LevelJustification levelJustification36 = new LevelJustification() { Val = LevelJustificationValues.Left };

      PreviousParagraphProperties previousParagraphProperties36 = new PreviousParagraphProperties();
      Indentation indentation36 = new Indentation() { Left = "6480", Hanging = "360" };

      previousParagraphProperties36.Append(indentation36);

      NumberingSymbolRunProperties numberingSymbolRunProperties18 = new NumberingSymbolRunProperties();
      RunFonts runFonts29 = new RunFonts() { Hint = FontTypeHintValues.Default, Ascii = "Wingdings", HighAnsi = "Wingdings" };

      numberingSymbolRunProperties18.Append(runFonts29);

      level36.Append(startNumberingValue36);
      level36.Append(numberingFormat36);
      level36.Append(levelText36);
      level36.Append(levelJustification36);
      level36.Append(previousParagraphProperties36);
      level36.Append(numberingSymbolRunProperties18);

      abstractNum4.Append(nsid4);
      abstractNum4.Append(multiLevelType4);
      abstractNum4.Append(templateCode4);
      abstractNum4.Append(level28);
      abstractNum4.Append(level29);
      abstractNum4.Append(level30);
      abstractNum4.Append(level31);
      abstractNum4.Append(level32);
      abstractNum4.Append(level33);
      abstractNum4.Append(level34);
      abstractNum4.Append(level35);
      abstractNum4.Append(level36);

      NumberingInstance numberingInstance1 = new NumberingInstance() { NumberID = 1 };
      AbstractNumId abstractNumId1 = new AbstractNumId() { Val = 3 };

      numberingInstance1.Append(abstractNumId1);

      NumberingInstance numberingInstance2 = new NumberingInstance() { NumberID = 2 };
      AbstractNumId abstractNumId2 = new AbstractNumId() { Val = 2 };

      numberingInstance2.Append(abstractNumId2);

      NumberingInstance numberingInstance3 = new NumberingInstance() { NumberID = 3 };
      AbstractNumId abstractNumId3 = new AbstractNumId() { Val = 0 };

      numberingInstance3.Append(abstractNumId3);

      NumberingInstance numberingInstance4 = new NumberingInstance() { NumberID = 4 };
      AbstractNumId abstractNumId4 = new AbstractNumId() { Val = 1 };

      numberingInstance4.Append(abstractNumId4);

      numbering1.Append(abstractNum1);
      numbering1.Append(abstractNum2);
      numbering1.Append(abstractNum3);
      numbering1.Append(abstractNum4);
      numbering1.Append(numberingInstance1);
      numbering1.Append(numberingInstance2);
      numbering1.Append(numberingInstance3);
      numbering1.Append(numberingInstance4);

      numberingDefinitionsPart1.Numbering = numbering1;
    }

    // Generates content of fontTablePart1.
    private void GenerateFontTablePart1Content(FontTablePart fontTablePart1)
    {
      Fonts fonts1 = new Fonts() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14" } };
      fonts1.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
      fonts1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
      fonts1.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
      fonts1.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");

      Font font1 = new Font() { Name = "Arial" };
      Panose1Number panose1Number1 = new Panose1Number() { Val = "020B0604020202020204" };
      FontCharSet fontCharSet1 = new FontCharSet() { Val = "00" };
      FontFamily fontFamily1 = new FontFamily() { Val = FontFamilyValues.Swiss };
      Pitch pitch1 = new Pitch() { Val = FontPitchValues.Variable };
      FontSignature fontSignature1 = new FontSignature() { UnicodeSignature0 = "E0002AFF", UnicodeSignature1 = "C0007843", UnicodeSignature2 = "00000009", UnicodeSignature3 = "00000000", CodePageSignature0 = "000001FF", CodePageSignature1 = "00000000" };

      font1.Append(panose1Number1);
      font1.Append(fontCharSet1);
      font1.Append(fontFamily1);
      font1.Append(pitch1);
      font1.Append(fontSignature1);

      Font font2 = new Font() { Name = "Times New Roman" };
      Panose1Number panose1Number2 = new Panose1Number() { Val = "02020603050405020304" };
      FontCharSet fontCharSet2 = new FontCharSet() { Val = "00" };
      FontFamily fontFamily2 = new FontFamily() { Val = FontFamilyValues.Roman };
      Pitch pitch2 = new Pitch() { Val = FontPitchValues.Variable };
      FontSignature fontSignature2 = new FontSignature() { UnicodeSignature0 = "E0002AFF", UnicodeSignature1 = "C0007841", UnicodeSignature2 = "00000009", UnicodeSignature3 = "00000000", CodePageSignature0 = "000001FF", CodePageSignature1 = "00000000" };

      font2.Append(panose1Number2);
      font2.Append(fontCharSet2);
      font2.Append(fontFamily2);
      font2.Append(pitch2);
      font2.Append(fontSignature2);

      Font font3 = new Font() { Name = "Symbol" };
      Panose1Number panose1Number3 = new Panose1Number() { Val = "05050102010706020507" };
      FontCharSet fontCharSet3 = new FontCharSet() { Val = "02" };
      FontFamily fontFamily3 = new FontFamily() { Val = FontFamilyValues.Roman };
      Pitch pitch3 = new Pitch() { Val = FontPitchValues.Variable };
      FontSignature fontSignature3 = new FontSignature() { UnicodeSignature0 = "00000000", UnicodeSignature1 = "10000000", UnicodeSignature2 = "00000000", UnicodeSignature3 = "00000000", CodePageSignature0 = "80000000", CodePageSignature1 = "00000000" };

      font3.Append(panose1Number3);
      font3.Append(fontCharSet3);
      font3.Append(fontFamily3);
      font3.Append(pitch3);
      font3.Append(fontSignature3);

      Font font4 = new Font() { Name = "Courier New" };
      Panose1Number panose1Number4 = new Panose1Number() { Val = "02070309020205020404" };
      FontCharSet fontCharSet4 = new FontCharSet() { Val = "00" };
      FontFamily fontFamily4 = new FontFamily() { Val = FontFamilyValues.Modern };
      Pitch pitch4 = new Pitch() { Val = FontPitchValues.Fixed };
      FontSignature fontSignature4 = new FontSignature() { UnicodeSignature0 = "E0002AFF", UnicodeSignature1 = "C0007843", UnicodeSignature2 = "00000009", UnicodeSignature3 = "00000000", CodePageSignature0 = "000001FF", CodePageSignature1 = "00000000" };

      font4.Append(panose1Number4);
      font4.Append(fontCharSet4);
      font4.Append(fontFamily4);
      font4.Append(pitch4);
      font4.Append(fontSignature4);

      Font font5 = new Font() { Name = "Wingdings" };
      Panose1Number panose1Number5 = new Panose1Number() { Val = "05000000000000000000" };
      FontCharSet fontCharSet5 = new FontCharSet() { Val = "02" };
      FontFamily fontFamily5 = new FontFamily() { Val = FontFamilyValues.Auto };
      Pitch pitch5 = new Pitch() { Val = FontPitchValues.Variable };
      FontSignature fontSignature5 = new FontSignature() { UnicodeSignature0 = "00000000", UnicodeSignature1 = "10000000", UnicodeSignature2 = "00000000", UnicodeSignature3 = "00000000", CodePageSignature0 = "80000000", CodePageSignature1 = "00000000" };

      font5.Append(panose1Number5);
      font5.Append(fontCharSet5);
      font5.Append(fontFamily5);
      font5.Append(pitch5);
      font5.Append(fontSignature5);

      Font font6 = new Font() { Name = "Calibri" };
      Panose1Number panose1Number6 = new Panose1Number() { Val = "020F0502020204030204" };
      FontCharSet fontCharSet6 = new FontCharSet() { Val = "00" };
      FontFamily fontFamily6 = new FontFamily() { Val = FontFamilyValues.Swiss };
      Pitch pitch6 = new Pitch() { Val = FontPitchValues.Variable };
      FontSignature fontSignature6 = new FontSignature() { UnicodeSignature0 = "E10002FF", UnicodeSignature1 = "4000ACFF", UnicodeSignature2 = "00000009", UnicodeSignature3 = "00000000", CodePageSignature0 = "0000019F", CodePageSignature1 = "00000000" };

      font6.Append(panose1Number6);
      font6.Append(fontCharSet6);
      font6.Append(fontFamily6);
      font6.Append(pitch6);
      font6.Append(fontSignature6);

      Font font7 = new Font() { Name = "Cambria" };
      Panose1Number panose1Number7 = new Panose1Number() { Val = "02040503050406030204" };
      FontCharSet fontCharSet7 = new FontCharSet() { Val = "00" };
      FontFamily fontFamily7 = new FontFamily() { Val = FontFamilyValues.Roman };
      Pitch pitch7 = new Pitch() { Val = FontPitchValues.Variable };
      FontSignature fontSignature7 = new FontSignature() { UnicodeSignature0 = "E00002FF", UnicodeSignature1 = "400004FF", UnicodeSignature2 = "00000000", UnicodeSignature3 = "00000000", CodePageSignature0 = "0000019F", CodePageSignature1 = "00000000" };

      font7.Append(panose1Number7);
      font7.Append(fontCharSet7);
      font7.Append(fontFamily7);
      font7.Append(pitch7);
      font7.Append(fontSignature7);

      Font font8 = new Font() { Name = "Consolas" };
      Panose1Number panose1Number8 = new Panose1Number() { Val = "020B0609020204030204" };
      FontCharSet fontCharSet8 = new FontCharSet() { Val = "00" };
      FontFamily fontFamily8 = new FontFamily() { Val = FontFamilyValues.Modern };
      Pitch pitch8 = new Pitch() { Val = FontPitchValues.Fixed };
      FontSignature fontSignature8 = new FontSignature() { UnicodeSignature0 = "E10002FF", UnicodeSignature1 = "4000FCFF", UnicodeSignature2 = "00000009", UnicodeSignature3 = "00000000", CodePageSignature0 = "0000019F", CodePageSignature1 = "00000000" };

      font8.Append(panose1Number8);
      font8.Append(fontCharSet8);
      font8.Append(fontFamily8);
      font8.Append(pitch8);
      font8.Append(fontSignature8);

      fonts1.Append(font1);
      fonts1.Append(font2);
      fonts1.Append(font3);
      fonts1.Append(font4);
      fonts1.Append(font5);
      fonts1.Append(font6);
      fonts1.Append(font7);
      fonts1.Append(font8);

      fontTablePart1.Fonts = fonts1;
    }

    // Generates content of webSettingsPart1.
    private void GenerateWebSettingsPart1Content(WebSettingsPart webSettingsPart1)
    {
      WebSettings webSettings1 = new WebSettings() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14" } };
      webSettings1.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
      webSettings1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
      webSettings1.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
      webSettings1.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");

      Divs divs1 = new Divs();

      Div div1 = new Div() { Id = "164902802" };
      BodyDiv bodyDiv1 = new BodyDiv() { Val = true };
      LeftMarginDiv leftMarginDiv1 = new LeftMarginDiv() { Val = "0" };
      RightMarginDiv rightMarginDiv1 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv1 = new TopMarginDiv() { Val = "0" };
      BottomMarginDiv bottomMarginDiv1 = new BottomMarginDiv() { Val = "0" };

      DivBorder divBorder1 = new DivBorder();
      TopBorder topBorder1 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder1 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder3 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder1 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder1.Append(topBorder1);
      divBorder1.Append(leftBorder1);
      divBorder1.Append(bottomBorder3);
      divBorder1.Append(rightBorder1);

      DivsChild divsChild1 = new DivsChild();

      Div div2 = new Div() { Id = "585188781" };
      LeftMarginDiv leftMarginDiv2 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv2 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv2 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv2 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder2 = new DivBorder();
      TopBorder topBorder2 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder2 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder4 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder2 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder2.Append(topBorder2);
      divBorder2.Append(leftBorder2);
      divBorder2.Append(bottomBorder4);
      divBorder2.Append(rightBorder2);

      div2.Append(leftMarginDiv2);
      div2.Append(rightMarginDiv2);
      div2.Append(topMarginDiv2);
      div2.Append(bottomMarginDiv2);
      div2.Append(divBorder2);

      Div div3 = new Div() { Id = "694617544" };
      LeftMarginDiv leftMarginDiv3 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv3 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv3 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv3 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder3 = new DivBorder();
      TopBorder topBorder3 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder3 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder5 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder3 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder3.Append(topBorder3);
      divBorder3.Append(leftBorder3);
      divBorder3.Append(bottomBorder5);
      divBorder3.Append(rightBorder3);

      div3.Append(leftMarginDiv3);
      div3.Append(rightMarginDiv3);
      div3.Append(topMarginDiv3);
      div3.Append(bottomMarginDiv3);
      div3.Append(divBorder3);

      Div div4 = new Div() { Id = "1745296518" };
      LeftMarginDiv leftMarginDiv4 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv4 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv4 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv4 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder4 = new DivBorder();
      TopBorder topBorder4 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder4 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder6 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder4 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder4.Append(topBorder4);
      divBorder4.Append(leftBorder4);
      divBorder4.Append(bottomBorder6);
      divBorder4.Append(rightBorder4);

      div4.Append(leftMarginDiv4);
      div4.Append(rightMarginDiv4);
      div4.Append(topMarginDiv4);
      div4.Append(bottomMarginDiv4);
      div4.Append(divBorder4);

      Div div5 = new Div() { Id = "1544514305" };
      LeftMarginDiv leftMarginDiv5 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv5 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv5 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv5 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder5 = new DivBorder();
      TopBorder topBorder5 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder5 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder7 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder5 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder5.Append(topBorder5);
      divBorder5.Append(leftBorder5);
      divBorder5.Append(bottomBorder7);
      divBorder5.Append(rightBorder5);

      div5.Append(leftMarginDiv5);
      div5.Append(rightMarginDiv5);
      div5.Append(topMarginDiv5);
      div5.Append(bottomMarginDiv5);
      div5.Append(divBorder5);

      Div div6 = new Div() { Id = "1025255640" };
      LeftMarginDiv leftMarginDiv6 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv6 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv6 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv6 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder6 = new DivBorder();
      TopBorder topBorder6 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder6 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder8 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder6 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder6.Append(topBorder6);
      divBorder6.Append(leftBorder6);
      divBorder6.Append(bottomBorder8);
      divBorder6.Append(rightBorder6);

      div6.Append(leftMarginDiv6);
      div6.Append(rightMarginDiv6);
      div6.Append(topMarginDiv6);
      div6.Append(bottomMarginDiv6);
      div6.Append(divBorder6);

      Div div7 = new Div() { Id = "1790471719" };
      LeftMarginDiv leftMarginDiv7 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv7 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv7 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv7 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder7 = new DivBorder();
      TopBorder topBorder7 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder7 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder9 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder7 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder7.Append(topBorder7);
      divBorder7.Append(leftBorder7);
      divBorder7.Append(bottomBorder9);
      divBorder7.Append(rightBorder7);

      div7.Append(leftMarginDiv7);
      div7.Append(rightMarginDiv7);
      div7.Append(topMarginDiv7);
      div7.Append(bottomMarginDiv7);
      div7.Append(divBorder7);

      divsChild1.Append(div2);
      divsChild1.Append(div3);
      divsChild1.Append(div4);
      divsChild1.Append(div5);
      divsChild1.Append(div6);
      divsChild1.Append(div7);

      div1.Append(bodyDiv1);
      div1.Append(leftMarginDiv1);
      div1.Append(rightMarginDiv1);
      div1.Append(topMarginDiv1);
      div1.Append(bottomMarginDiv1);
      div1.Append(divBorder1);
      div1.Append(divsChild1);

      Div div8 = new Div() { Id = "836070930" };
      BodyDiv bodyDiv2 = new BodyDiv() { Val = true };
      LeftMarginDiv leftMarginDiv8 = new LeftMarginDiv() { Val = "0" };
      RightMarginDiv rightMarginDiv8 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv8 = new TopMarginDiv() { Val = "0" };
      BottomMarginDiv bottomMarginDiv8 = new BottomMarginDiv() { Val = "0" };

      DivBorder divBorder8 = new DivBorder();
      TopBorder topBorder8 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder8 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder10 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder8 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder8.Append(topBorder8);
      divBorder8.Append(leftBorder8);
      divBorder8.Append(bottomBorder10);
      divBorder8.Append(rightBorder8);

      DivsChild divsChild2 = new DivsChild();

      Div div9 = new Div() { Id = "1477839258" };
      LeftMarginDiv leftMarginDiv9 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv9 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv9 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv9 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder9 = new DivBorder();
      TopBorder topBorder9 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder9 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder11 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder9 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder9.Append(topBorder9);
      divBorder9.Append(leftBorder9);
      divBorder9.Append(bottomBorder11);
      divBorder9.Append(rightBorder9);

      div9.Append(leftMarginDiv9);
      div9.Append(rightMarginDiv9);
      div9.Append(topMarginDiv9);
      div9.Append(bottomMarginDiv9);
      div9.Append(divBorder9);

      Div div10 = new Div() { Id = "1855146031" };
      LeftMarginDiv leftMarginDiv10 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv10 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv10 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv10 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder10 = new DivBorder();
      TopBorder topBorder10 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder10 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder12 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder10 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder10.Append(topBorder10);
      divBorder10.Append(leftBorder10);
      divBorder10.Append(bottomBorder12);
      divBorder10.Append(rightBorder10);

      div10.Append(leftMarginDiv10);
      div10.Append(rightMarginDiv10);
      div10.Append(topMarginDiv10);
      div10.Append(bottomMarginDiv10);
      div10.Append(divBorder10);

      Div div11 = new Div() { Id = "1113281013" };
      LeftMarginDiv leftMarginDiv11 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv11 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv11 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv11 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder11 = new DivBorder();
      TopBorder topBorder11 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder11 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder13 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder11 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder11.Append(topBorder11);
      divBorder11.Append(leftBorder11);
      divBorder11.Append(bottomBorder13);
      divBorder11.Append(rightBorder11);

      div11.Append(leftMarginDiv11);
      div11.Append(rightMarginDiv11);
      div11.Append(topMarginDiv11);
      div11.Append(bottomMarginDiv11);
      div11.Append(divBorder11);

      Div div12 = new Div() { Id = "1116212831" };
      LeftMarginDiv leftMarginDiv12 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv12 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv12 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv12 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder12 = new DivBorder();
      TopBorder topBorder12 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder12 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder14 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder12 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder12.Append(topBorder12);
      divBorder12.Append(leftBorder12);
      divBorder12.Append(bottomBorder14);
      divBorder12.Append(rightBorder12);

      div12.Append(leftMarginDiv12);
      div12.Append(rightMarginDiv12);
      div12.Append(topMarginDiv12);
      div12.Append(bottomMarginDiv12);
      div12.Append(divBorder12);

      Div div13 = new Div() { Id = "2094279010" };
      LeftMarginDiv leftMarginDiv13 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv13 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv13 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv13 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder13 = new DivBorder();
      TopBorder topBorder13 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder13 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder15 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder13 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder13.Append(topBorder13);
      divBorder13.Append(leftBorder13);
      divBorder13.Append(bottomBorder15);
      divBorder13.Append(rightBorder13);

      div13.Append(leftMarginDiv13);
      div13.Append(rightMarginDiv13);
      div13.Append(topMarginDiv13);
      div13.Append(bottomMarginDiv13);
      div13.Append(divBorder13);

      Div div14 = new Div() { Id = "333651614" };
      LeftMarginDiv leftMarginDiv14 = new LeftMarginDiv() { Val = "547" };
      RightMarginDiv rightMarginDiv14 = new RightMarginDiv() { Val = "0" };
      TopMarginDiv topMarginDiv14 = new TopMarginDiv() { Val = "134" };
      BottomMarginDiv bottomMarginDiv14 = new BottomMarginDiv() { Val = "120" };

      DivBorder divBorder14 = new DivBorder();
      TopBorder topBorder14 = new TopBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      LeftBorder leftBorder14 = new LeftBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      BottomBorder bottomBorder16 = new BottomBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };
      RightBorder rightBorder14 = new RightBorder() { Val = BorderValues.None, Color = "auto", Size = (UInt32Value)0U, Space = (UInt32Value)0U };

      divBorder14.Append(topBorder14);
      divBorder14.Append(leftBorder14);
      divBorder14.Append(bottomBorder16);
      divBorder14.Append(rightBorder14);

      div14.Append(leftMarginDiv14);
      div14.Append(rightMarginDiv14);
      div14.Append(topMarginDiv14);
      div14.Append(bottomMarginDiv14);
      div14.Append(divBorder14);

      divsChild2.Append(div9);
      divsChild2.Append(div10);
      divsChild2.Append(div11);
      divsChild2.Append(div12);
      divsChild2.Append(div13);
      divsChild2.Append(div14);

      div8.Append(bodyDiv2);
      div8.Append(leftMarginDiv8);
      div8.Append(rightMarginDiv8);
      div8.Append(topMarginDiv8);
      div8.Append(bottomMarginDiv8);
      div8.Append(divBorder8);
      div8.Append(divsChild2);

      divs1.Append(div1);
      divs1.Append(div8);
      OptimizeForBrowser optimizeForBrowser1 = new OptimizeForBrowser();
      AllowPNG allowPNG1 = new AllowPNG();

      webSettings1.Append(divs1);
      webSettings1.Append(optimizeForBrowser1);
      webSettings1.Append(allowPNG1);

      webSettingsPart1.WebSettings = webSettings1;
    }

    // Generates content of documentSettingsPart1.
    private void GenerateDocumentSettingsPart1Content(DocumentSettingsPart documentSettingsPart1)
    {
      Settings settings1 = new Settings() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14" } };
      settings1.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
      settings1.AddNamespaceDeclaration("o", "urn:schemas-microsoft-com:office:office");
      settings1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
      settings1.AddNamespaceDeclaration("m", "http://schemas.openxmlformats.org/officeDocument/2006/math");
      settings1.AddNamespaceDeclaration("v", "urn:schemas-microsoft-com:vml");
      settings1.AddNamespaceDeclaration("w10", "urn:schemas-microsoft-com:office:word");
      settings1.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
      settings1.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");
      settings1.AddNamespaceDeclaration("sl", "http://schemas.openxmlformats.org/schemaLibrary/2006/main");
      Zoom zoom1 = new Zoom() { Percent = "100" };
      ProofState proofState1 = new ProofState() { Spelling = ProofingStateValues.Clean, Grammar = ProofingStateValues.Clean };
      DefaultTabStop defaultTabStop1 = new DefaultTabStop() { Val = 720 };
      CharacterSpacingControl characterSpacingControl1 = new CharacterSpacingControl() { Val = CharacterSpacingValues.DoNotCompress };

      Compatibility compatibility1 = new Compatibility();
      CompatibilitySetting compatibilitySetting1 = new CompatibilitySetting() { Name = CompatSettingNameValues.CompatibilityMode, Uri = "http://schemas.microsoft.com/office/word", Val = "14" };
      CompatibilitySetting compatibilitySetting2 = new CompatibilitySetting() { Name = CompatSettingNameValues.OverrideTableStyleFontSizeAndJustification, Uri = "http://schemas.microsoft.com/office/word", Val = "1" };
      CompatibilitySetting compatibilitySetting3 = new CompatibilitySetting() { Name = CompatSettingNameValues.EnableOpenTypeFeatures, Uri = "http://schemas.microsoft.com/office/word", Val = "1" };
      CompatibilitySetting compatibilitySetting4 = new CompatibilitySetting() { Name = CompatSettingNameValues.DoNotFlipMirrorIndents, Uri = "http://schemas.microsoft.com/office/word", Val = "1" };

      compatibility1.Append(compatibilitySetting1);
      compatibility1.Append(compatibilitySetting2);
      compatibility1.Append(compatibilitySetting3);
      compatibility1.Append(compatibilitySetting4);

      Rsids rsids1 = new Rsids();
      RsidRoot rsidRoot1 = new RsidRoot() { Val = "00146275" };
      Rsid rsid11 = new Rsid() { Val = "00146275" };
      Rsid rsid12 = new Rsid() { Val = "00331009" };
      Rsid rsid13 = new Rsid() { Val = "004911E3" };
      Rsid rsid14 = new Rsid() { Val = "009E69E7" };
      Rsid rsid15 = new Rsid() { Val = "00AD10BA" };
      Rsid rsid16 = new Rsid() { Val = "00C5783A" };
      Rsid rsid17 = new Rsid() { Val = "00EB3E0F" };

      rsids1.Append(rsidRoot1);
      rsids1.Append(rsid11);
      rsids1.Append(rsid12);
      rsids1.Append(rsid13);
      rsids1.Append(rsid14);
      rsids1.Append(rsid15);
      rsids1.Append(rsid16);
      rsids1.Append(rsid17);

      M.MathProperties mathProperties1 = new M.MathProperties();
      M.MathFont mathFont1 = new M.MathFont() { Val = "Cambria Math" };
      M.BreakBinary breakBinary1 = new M.BreakBinary() { Val = M.BreakBinaryOperatorValues.Before };
      M.BreakBinarySubtraction breakBinarySubtraction1 = new M.BreakBinarySubtraction() { Val = M.BreakBinarySubtractionValues.MinusMinus };
      M.SmallFraction smallFraction1 = new M.SmallFraction() { Val = M.BooleanValues.Zero };
      M.DisplayDefaults displayDefaults1 = new M.DisplayDefaults();
      M.LeftMargin leftMargin1 = new M.LeftMargin() { Val = (UInt32Value)0U };
      M.RightMargin rightMargin1 = new M.RightMargin() { Val = (UInt32Value)0U };
      M.DefaultJustification defaultJustification1 = new M.DefaultJustification() { Val = M.JustificationValues.CenterGroup };
      M.WrapIndent wrapIndent1 = new M.WrapIndent() { Val = (UInt32Value)1440U };
      M.IntegralLimitLocation integralLimitLocation1 = new M.IntegralLimitLocation() { Val = M.LimitLocationValues.SubscriptSuperscript };
      M.NaryLimitLocation naryLimitLocation1 = new M.NaryLimitLocation() { Val = M.LimitLocationValues.UnderOver };

      mathProperties1.Append(mathFont1);
      mathProperties1.Append(breakBinary1);
      mathProperties1.Append(breakBinarySubtraction1);
      mathProperties1.Append(smallFraction1);
      mathProperties1.Append(displayDefaults1);
      mathProperties1.Append(leftMargin1);
      mathProperties1.Append(rightMargin1);
      mathProperties1.Append(defaultJustification1);
      mathProperties1.Append(wrapIndent1);
      mathProperties1.Append(integralLimitLocation1);
      mathProperties1.Append(naryLimitLocation1);
      ThemeFontLanguages themeFontLanguages1 = new ThemeFontLanguages() { Val = "en-AU" };
      ColorSchemeMapping colorSchemeMapping1 = new ColorSchemeMapping() { Background1 = ColorSchemeIndexValues.Light1, Text1 = ColorSchemeIndexValues.Dark1, Background2 = ColorSchemeIndexValues.Light2, Text2 = ColorSchemeIndexValues.Dark2, Accent1 = ColorSchemeIndexValues.Accent1, Accent2 = ColorSchemeIndexValues.Accent2, Accent3 = ColorSchemeIndexValues.Accent3, Accent4 = ColorSchemeIndexValues.Accent4, Accent5 = ColorSchemeIndexValues.Accent5, Accent6 = ColorSchemeIndexValues.Accent6, Hyperlink = ColorSchemeIndexValues.Hyperlink, FollowedHyperlink = ColorSchemeIndexValues.FollowedHyperlink };

      ShapeDefaults shapeDefaults1 = new ShapeDefaults();
      Ovml.ShapeDefaults shapeDefaults2 = new Ovml.ShapeDefaults() { Extension = V.ExtensionHandlingBehaviorValues.Edit, MaxShapeId = 1026 };

      Ovml.ShapeLayout shapeLayout1 = new Ovml.ShapeLayout() { Extension = V.ExtensionHandlingBehaviorValues.Edit };
      Ovml.ShapeIdMap shapeIdMap1 = new Ovml.ShapeIdMap() { Extension = V.ExtensionHandlingBehaviorValues.Edit, Data = "1" };

      shapeLayout1.Append(shapeIdMap1);

      shapeDefaults1.Append(shapeDefaults2);
      shapeDefaults1.Append(shapeLayout1);
      DecimalSymbol decimalSymbol1 = new DecimalSymbol() { Val = "." };
      ListSeparator listSeparator1 = new ListSeparator() { Val = "," };
      W14.DocumentId documentId1 = new W14.DocumentId() { Val = "221B87E0" };

      settings1.Append(zoom1);
      settings1.Append(proofState1);
      settings1.Append(defaultTabStop1);
      settings1.Append(characterSpacingControl1);
      settings1.Append(compatibility1);
      settings1.Append(rsids1);
      settings1.Append(mathProperties1);
      settings1.Append(themeFontLanguages1);
      settings1.Append(colorSchemeMapping1);
      settings1.Append(shapeDefaults1);
      settings1.Append(decimalSymbol1);
      settings1.Append(listSeparator1);
      settings1.Append(documentId1);

      documentSettingsPart1.Settings = settings1;
    }

    private void SetPackageProperties(OpenXmlPackage document)
    {
      document.PackageProperties.Creator = "Andrew Coates (DPE AUSTRALIA)";
      document.PackageProperties.Revision = "2";
      document.PackageProperties.Created = System.Xml.XmlConvert.ToDateTime("2010-06-19T05:01:00Z", System.Xml.XmlDateTimeSerializationMode.RoundtripKind);
      document.PackageProperties.Modified = System.Xml.XmlConvert.ToDateTime("2010-06-19T05:01:00Z", System.Xml.XmlDateTimeSerializationMode.RoundtripKind);
      document.PackageProperties.LastModifiedBy = "Andrew Coates (DPE AUSTRALIA)";
    }




  }
}
