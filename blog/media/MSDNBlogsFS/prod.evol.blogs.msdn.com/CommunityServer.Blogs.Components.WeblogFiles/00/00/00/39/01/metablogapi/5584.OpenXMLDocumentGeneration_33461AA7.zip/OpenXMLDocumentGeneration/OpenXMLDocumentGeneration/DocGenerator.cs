﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

using SPC = Microsoft.SharePoint.Client;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;



namespace OpenXMLDocumentGeneration
{
  class DocGenerator
  {
    DocumentCreator gen = new DocumentCreator();
    string OutputFolder = @"c:\temp\";
    Stopwatch sw = new Stopwatch();

    internal void CreateOneDocumentLocally()
    {
      sw.Reset();
      sw.Start();
      gen.CreatePackage(OutputFolder + "MyNextOpenXMLDocument.docx");
      sw.Stop();
      System.Windows.Forms.MessageBox.Show(string.Format("Created 1 document in {0} ms", sw.ElapsedMilliseconds));
    }

    internal void CreateManyDocumentsLocally(int NumberOfDocs)
    {
      sw.Reset();
      sw.Start();
      for (int i = 0; i < NumberOfDocs; i++)
      {
        gen.CreatePackage(string.Format("{0}MyNextOpenXMLDocument{1:D5}.docx",
           OutputFolder, i));
      }
      sw.Stop();
      System.Windows.Forms.MessageBox.Show(string.Format("Created {1} documents in {0} ms", sw.ElapsedMilliseconds, NumberOfDocs));
    }


    internal void CreateManyDocumentsLocallyInParallel(int NumberOfDocs)
    {
      System.Threading.Tasks.Parallel.For(0, NumberOfDocs, i =>
      {
        gen.CreatePackage(string.Format("{0}MyNextOpenXMLDocument{1:D5}.docx",
            OutputFolder, i));
      });

    }

    internal void CreateOneDocumentOnSharePoint()
    {
      SPC.ClientContext clientContext = new SPC.ClientContext("http://localhost");
      string fileUrl = "/Created Docs/MyVeryVeryCoolDoc.docx";

      sw.Reset();
      sw.Start();

      using (MemoryStream ms = gen.CreatePackage())
      {
        ms.Seek(0, SeekOrigin.Begin);
        SPC.File.SaveBinaryDirect(clientContext, fileUrl, ms, true);
      }

      sw.Stop();

      System.Windows.Forms.MessageBox.Show(string.Format(
          "Wrote 1 document to SharePoint ({1}{2}) in {0} ms",
          sw.ElapsedMilliseconds,
          clientContext.Url,
          fileUrl));

    }

    internal void CreateManyDocumentsOnSharePoint(int NumberOfDocs)
    {
      SPC.ClientContext clientContext = new SPC.ClientContext("http://localhost");
      string fileUrl = "/Created Docs/MyEvenCoolerDoc{0:D5}.docx";

      sw.Reset();
      sw.Start();

      for (int i = 0; i < NumberOfDocs; i++)
      {

        using (MemoryStream ms = gen.CreatePackage())
        {
          ms.Seek(0, SeekOrigin.Begin);
          SPC.File.SaveBinaryDirect(clientContext, string.Format(fileUrl, i), ms, true);
        }

      }

      sw.Stop();

      System.Windows.Forms.MessageBox.Show(string.Format(
          "Wrote {3} documents to SharePoint ({1}{2}) in {0} ms",
          sw.ElapsedMilliseconds,
          clientContext.Url,
          fileUrl,
          NumberOfDocs));

    }
    internal void CreateManyDocumentsOnSharePointInParallel(int NumberOfDocs)
    {
      SPC.ClientContext clientContext = new SPC.ClientContext("http://localhost");
      string fileUrl = "/Created Docs/MyEvenCoolerDoc{0:D5}.docx";

      sw.Reset();
      sw.Start();

      Parallel.For(0, NumberOfDocs, i =>
      {

        using (MemoryStream ms = gen.CreatePackage())
        {
          ms.Seek(0, SeekOrigin.Begin);
          SPC.File.SaveBinaryDirect(clientContext, string.Format(fileUrl, i), ms, true);
        }

      });

      sw.Stop();

      System.Windows.Forms.MessageBox.Show(string.Format(
          "Wrote {3} documents to SharePoint ({1}{2}) in {0} ms (using parallel processing)",
          sw.ElapsedMilliseconds,
          clientContext.Url,
          fileUrl,
          NumberOfDocs));

    }
  }
}