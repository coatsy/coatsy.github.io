﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

using Microsoft.SharePoint.Client;
using OM = Microsoft.SharePoint.Client;
using System.IO;



namespace OpenXMLDocumentGeneration
{
  public partial class Form1 : System.Windows.Forms.Form
  {
    DocGenerator gen = new DocGenerator();
    Stopwatch sw = new Stopwatch();

    public Form1()
    {
      InitializeComponent();
    }

    private void CreateOneDocumentLocallyButton_Click(object sender, EventArgs e)
    {
      sw.Reset();
      sw.Start();
      gen.CreateOneDocumentLocally();
      sw.Stop();
      MessageBox.Show(String.Format("Created one document locally in {0} ms",
         sw.ElapsedMilliseconds));
    }

    private void CreateManyDocumentsLocallyButton_Click(object sender, EventArgs e)
    {
      sw.Reset();
      sw.Start();
      gen.CreateManyDocumentsLocallyInParallel((int)NumberOfDocumentsToCreate.Value);
      sw.Stop();
      MessageBox.Show(String.Format("Created {1} documents locally in {0} ms",
         sw.ElapsedMilliseconds, (int)NumberOfDocumentsToCreate.Value));

    }

    private void CreateOneDocumentOnSharePointButton_Click(object sender, EventArgs e)
    {
      gen.CreateOneDocumentOnSharePoint();
    }

    private void CreateManyDocumentsOnSharePointButton_Click(object sender, EventArgs e)
    {
      gen.CreateManyDocumentsOnSharePointInParallel((int)NumberOfDocumentsToCreate.Value);

    }
  }
}